#!/usr/bin/env python3
"""Fake INAV flight controller for testing bridge.py without hardware.

Usage on any Linux PC:   python3 tools/fake_fc.py
It prints a device name (e.g. /dev/pts/3). Put that into fpv-config.txt as msp_port
and start bridge.py. The fake FC answers MSP like a real one and shows override frames.
"""
import os
import pty
import struct
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from bridge import (MSP_ANALOG, MSP_ATTITUDE, MSP_BOXIDS, MSP_RAW_GPS, MSP_RC,  # noqa: E402
                    MSP_RX_MAP, MSP_SET_RAW_RC, MSP_STATUS)


class FakeFC:
    def __init__(self):
        self.lq = 100            # percent
        self.override_sw = True
        self.armed = True
        self.rcmap = [0, 1, 3, 2]            # like INAV "AETR": raw = A, E, T, R
        self.rc = [1500, 1500, 1500, 1500, 2000, 1000, 1500, 1500] + [1500] * 8
        self.boxids = [0, 1, 50, 27]         # ARM, ANGLE, MSP RC OVERRIDE, FAILSAFE
        self.set_frames = []

    def answer(self, cmd, payload):
        if cmd == MSP_RX_MAP:
            return bytes(self.rcmap)
        if cmd == MSP_BOXIDS:
            return bytes(self.boxids)
        if cmd == MSP_STATUS:
            flags = (1 if self.armed else 0) | ((1 << 2) if self.override_sw else 0)
            return struct.pack("<HHHIB", 1000, 0, 0x21, flags, 0)
        if cmd == MSP_RC:
            return struct.pack("<%dH" % len(self.rc), *self.rc)
        if cmd == MSP_RAW_GPS:
            return struct.pack("<BBiihHHH", 2, 15, 481873608, 156138869, 270, 833, 900, 120)
        if cmd == MSP_ATTITUDE:
            return struct.pack("<hhh", 12, -34, 90)
        if cmd == MSP_ANALOG:
            return struct.pack("<BHHh", 240, 1234, int(self.lq * 1023 / 100), 350)
        if cmd == MSP_SET_RAW_RC:
            self.set_frames.append(struct.unpack("<%dH" % (len(payload) // 2), payload))
            return b""
        return None

    def feed(self, buf, write):
        """Consume complete requests from buf, write answers, return the rest."""
        while True:
            i = buf.find(b"$M<")
            if i < 0 or len(buf) < i + 6:
                return buf[i:] if i >= 0 else b""
            size, cmd = buf[i + 3], buf[i + 4]
            if len(buf) < i + 6 + size:
                return buf[i:]
            payload = buf[i + 5:i + 5 + size]
            buf = buf[i + 6 + size:]
            data = self.answer(cmd, payload)
            if data is None:
                continue
            body = bytes([len(data), cmd]) + data
            crc = 0
            for b in body:
                crc ^= b
            write(b"$M>" + body + bytes([crc]))


if __name__ == "__main__":
    master, slave = pty.openpty()
    print("Fake FC ready. Use this as msp_port:", os.ttyname(slave), flush=True)
    fc, buf, last = FakeFC(), b"", 0
    while True:
        buf = fc.feed(buf + os.read(master, 256), lambda d: os.write(master, d))
        if fc.set_frames and time.time() - last > 0.5:
            last = time.time()
            print("override frame:", fc.set_frames[-1][:8], flush=True)
