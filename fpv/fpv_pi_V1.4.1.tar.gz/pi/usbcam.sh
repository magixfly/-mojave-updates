#!/bin/bash
# Mojave FPV LTE V1.4.1 - one USB camera -> H.264 -> video server. Started by MediaMTX while somebody watches.
#   usbcam.sh DEVICE WIDTH HEIGHT FPS KBIT PATH [auto|hw|sw|ffmpeg]
# hw     = JPEG decoding and H.264 encoding both in the Pi's video chip (least load, least delay)
# sw     = JPEG decoding in software (GStreamer), encoding in the chip
# ffmpeg = the old way (most load)
# auto   = start with the last one that worked, step to the next if one stops within 8 seconds
D=$1; W=$2; H=$3; F=$4; K=$5; P=$6; MODE=${7:-auto}
URL="rtsp://localhost:8554/$P"
STATE="/run/fpv-usbcam-$P"
for c in power_line_frequency=1 exposure_dynamic_framerate=0 exposure_auto_priority=0; do
  v4l2-ctl -d "$D" -c "$c" >/dev/null 2>&1          # 50 Hz mains, keep the frame rate in the dark
done
ENC="v4l2h264enc extra-controls=controls,video_bitrate=$((K * 1000)),h264_i_frame_period=$F,repeat_sequence_header=1"
SINK="rtspclientsink location=$URL protocols=tcp latency=0"
run_hw() { gst-launch-1.0 -q v4l2src device="$D" do-timestamp=true ! "image/jpeg,width=$W,height=$H,framerate=$F/1" \
  ! v4l2jpegdec ! $ENC ! "video/x-h264,level=(string)4" ! h264parse config-interval=-1 ! $SINK; }
run_sw() { gst-launch-1.0 -q v4l2src device="$D" do-timestamp=true ! "image/jpeg,width=$W,height=$H,framerate=$F/1" \
  ! jpegdec ! videoconvert ! "video/x-raw,format=I420" ! $ENC ! "video/x-h264,level=(string)4" \
  ! h264parse config-interval=-1 ! $SINK; }
run_ffmpeg() { ffmpeg -hide_banner -loglevel warning -fflags nobuffer -flags low_delay -probesize 32 -analyzeduration 0 \
  -f v4l2 -input_format mjpeg -video_size "${W}x${H}" -framerate "$F" -i "$D" \
  -pix_fmt yuv420p -c:v h264_v4l2m2m -b:v "${K}k" -g "$F" -bf 0 -f rtsp -rtsp_transport tcp "$URL"; }
ORDER="hw sw ffmpeg"
if [ "$MODE" != "auto" ]; then echo "[usbcam] $P: fixed mode $MODE"; "run_$MODE"; exit $?; fi
cur=$(cat "$STATE" 2>/dev/null); case " $ORDER " in *" $cur "*) ;; *) cur=hw ;; esac
while true; do
  echo "[usbcam] $P: $D ${W}x${H}@$F ${K}k, mode $cur"
  t0=$(date +%s); "run_$cur"; dur=$(( $(date +%s) - t0 ))
  if [ "$dur" -ge 8 ]; then echo "$cur" > "$STATE"; exit 0; fi      # it worked for a while: keep this mode
  case $cur in hw) cur=sw ;; sw) cur=ffmpeg ;; *) echo "[usbcam] $P: no mode works"; rm -f "$STATE"; sleep 3; exit 1 ;; esac
  echo "$cur" > "$STATE"
done
