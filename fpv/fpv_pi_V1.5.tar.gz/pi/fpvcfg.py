"""Shared reader for /boot/firmware/fpv-config.txt (Mojave FPV LTE V1.5)."""
import os

VERSION = "V1.5"
CONFIG_PATHS = ["/boot/firmware/fpv-config.txt", "/boot/fpv-config.txt",
                os.path.join(os.path.dirname(os.path.abspath(__file__)), "fpv-config.txt")]

DEFAULTS = {
    "video_width": 1920, "video_height": 1080, "video_fps": 30,
    "video_bitrate_kbps": 4000, "video_idr_period": 30,
    "video_hflip": 0, "video_vflip": 0,
    "audio_enable": 1, "audio_device": "auto", "audio_bitrate_kbps": 24,
    "cam2_enable": 1, "cam2_device": "auto", "cam2_width": 1280,
    "cam2_height": 720, "cam2_fps": 30, "cam2_bitrate_kbps": 1500,
    "msp_port": "/dev/serial0", "msp_baud": 115200, "telemetry_hz": 10,
    "control_enable": 0, "lq_switch_pct": 50, "lq_switch_ms": 500,
    "lq_return_pct": 70, "lq_return_ms": 1000, "steer_axis": "roll",
    "steer_reverse": 0, "throttle_reverse": 0, "throttle_limit_pct": 30,
    "ground_timeout_ms": 300, "web_port": 8080,
    "control_mode": "override", "cam2_pipeline": "auto", "steer_channel": 1, "throttle_channel": 2,
    "throttle_neutral_us": 1500, "failsafe_hold_ms": 1000,
}

LIMITS = {  # name: (min, max) - values outside are pulled back into range
    "video_width": (320, 1920), "video_height": (240, 1080), "video_fps": (5, 30),
    "video_bitrate_kbps": (300, 20000), "video_idr_period": (1, 300),
    "audio_bitrate_kbps": (8, 128), "cam2_width": (320, 1920),
    "cam2_height": (240, 1080), "cam2_fps": (5, 30), "cam2_bitrate_kbps": (200, 8000),
    "msp_baud": (9600, 921600), "telemetry_hz": (1, 30),
    "lq_switch_pct": (5, 95), "lq_switch_ms": (100, 10000),
    "lq_return_pct": (10, 100), "lq_return_ms": (100, 20000),
    "throttle_limit_pct": (5, 100), "ground_timeout_ms": (100, 2000),
    "web_port": (1024, 65535),
    "steer_channel": (1, 8), "throttle_channel": (1, 8),
    "throttle_neutral_us": (1000, 2000), "failsafe_hold_ms": (0, 5000),
}


def find_config():
    if os.environ.get("FPV_CONFIG"):          # used by the tests
        return os.environ["FPV_CONFIG"] if os.path.isfile(os.environ["FPV_CONFIG"]) else None
    for p in CONFIG_PATHS:
        if os.path.isfile(p):
            return p
    return None


def load(path=None):
    """Return (settings dict, list of warnings). Unknown names are reported, not fatal."""
    cfg = dict(DEFAULTS)
    warnings = []
    path = path or find_config()
    if not path:
        warnings.append("fpv-config.txt not found - using built-in defaults")
        return cfg, warnings
    with open(path, encoding="utf-8", errors="replace") as f:
        for n, line in enumerate(f, 1):
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            if "=" not in line:
                warnings.append(f"line {n}: no '=' - ignored")
                continue
            key, val = [s.strip() for s in line.split("=", 1)]
            if key not in DEFAULTS:
                warnings.append(f"line {n}: unknown setting '{key}' - ignored")
                continue
            if isinstance(DEFAULTS[key], int):
                try:
                    val = int(float(val))
                except ValueError:
                    warnings.append(f"line {n}: '{key}' needs a number - default kept")
                    continue
                if key in LIMITS:
                    lo, hi = LIMITS[key]
                    if not lo <= val <= hi:
                        warnings.append(f"line {n}: '{key}' = {val} outside {lo}..{hi} - limited")
                        val = max(lo, min(hi, val))
            cfg[key] = val
    if cfg["control_mode"] not in ("override", "msp_rx"):
        warnings.append("control_mode must be override or msp_rx - using override")
        cfg["control_mode"] = "override"
    if cfg["steer_axis"] not in ("roll", "yaw"):
        warnings.append("steer_axis must be roll or yaw - using roll")
        cfg["steer_axis"] = "roll"
    if cfg["lq_return_pct"] <= cfg["lq_switch_pct"]:
        cfg["lq_return_pct"] = min(100, cfg["lq_switch_pct"] + 10)
        warnings.append("lq_return_pct must be above lq_switch_pct - corrected")
    return cfg, warnings


# ---- Description of every setting for the settings web page (V1.5) ----
# (key, group, label, kind, hint)   kind: int | bool | text | choice:a,b
FIELDS = [
    ("video_width", "Main camera", "Width (pixels)", "int", "1920 for Full HD, 1280 for 720p"),
    ("video_height", "Main camera", "Height (pixels)", "int", "1080 for Full HD, 720 for 720p"),
    ("video_fps", "Main camera", "Frames per second", "int", "This camera (IMX462) delivers 30 at most"),
    ("video_bitrate_kbps", "Main camera", "Bitrate (kbit/s)", "int", "4000 = 4 Mbit/s. Lower it if the mobile upload is weak"),
    ("video_idr_period", "Main camera", "Full picture every N frames", "int", "30 at 30 fps = once per second"),
    ("video_hflip", "Main camera", "Mirror left/right", "bool", ""),
    ("video_vflip", "Main camera", "Upside down", "bool", ""),
    ("audio_enable", "Sound", "Sound on", "bool", "Needs a USB microphone (e.g. in a USB camera). Heard with every camera, button SOUND in the cockpit"),
    ("audio_device", "Sound", "Microphone", "text", "auto = first USB microphone"),
    ("audio_bitrate_kbps", "Sound", "Bitrate (kbit/s)", "int", ""),
    ("cam2_enable", "Second camera (USB)", "Second camera on", "bool", "Runs only while somebody watches it"),
    ("cam2_device", "Second camera (USB)", "Device", "text", "auto = first USB camera"),
    ("cam2_width", "Second camera (USB)", "Width (pixels)", "int", ""),
    ("cam2_height", "Second camera (USB)", "Height (pixels)", "int", ""),
    ("cam2_fps", "Second camera (USB)", "Frames per second", "int", ""),
    ("cam2_bitrate_kbps", "Second camera (USB)", "Bitrate (kbit/s)", "int", ""),
    ("cam2_pipeline", "Second camera (USB)", "How the picture is converted", "choice:auto,hw,sw,ffmpeg",
     "auto = video chip up to 720p, software decoding above. Falls back to ffmpeg by itself"),
    ("msp_port", "Flight controller", "Serial port", "text", "/dev/serial0 = GPIO pins 8 and 10"),
    ("msp_baud", "Flight controller", "Baud rate", "int", "Must match the MSP port in INAV"),
    ("telemetry_hz", "Flight controller", "Cockpit updates per second", "int", ""),
    ("control_enable", "Control over IP (experimental)", "Allow control over IP", "bool",
     "Only with INAV mode MSP RC OVERRIDE on a switch"),
    ("control_mode", "Control over IP (experimental)", "How the Pi controls the car", "choice:override,msp_rx",
     "msp_rx = the Pi is the receiver (INAV receiver_type MSP, no ELRS). override = ELRS first, IP as backup"),
    ("steer_channel", "Control over IP (experimental)", "msp_rx: steering channel", "int", "Channel number of the transmitter, usually 1"),
    ("throttle_channel", "Control over IP (experimental)", "msp_rx: throttle channel", "int", "Usually 2 on a car transmitter"),
    ("throttle_neutral_us", "Control over IP (experimental)", "msp_rx: throttle neutral (us)", "int", "1500 for a car with reverse"),
    ("failsafe_hold_ms", "Control over IP (experimental)", "msp_rx: hold neutral before failsafe (ms)", "int",
     "After this time without commands the Pi stops sending and the FC failsafe takes over"),
    ("lq_switch_pct", "Control over IP (experimental)", "Switch to IP below link quality (%)", "int", ""),
    ("lq_switch_ms", "Control over IP (experimental)", "... for at least (ms)", "int", ""),
    ("lq_return_pct", "Control over IP (experimental)", "Back to ELRS above link quality (%)", "int", ""),
    ("lq_return_ms", "Control over IP (experimental)", "... for at least (ms)", "int", ""),
    ("steer_axis", "Control over IP (experimental)", "Steering axis", "choice:roll,yaw", ""),
    ("steer_reverse", "Control over IP (experimental)", "Reverse steering", "bool", ""),
    ("throttle_reverse", "Control over IP (experimental)", "Reverse throttle", "bool", ""),
    ("throttle_limit_pct", "Control over IP (experimental)", "Throttle limit (%)", "int", ""),
    ("ground_timeout_ms", "Control over IP (experimental)", "Neutral after silence (ms)", "int", ""),
    ("web_port", "Web pages", "Port of cockpit and settings", "int", "Changing it changes this page's address"),
]


def check_value(key, raw):
    """Validate one value from the settings page. Returns (clean value, error or None)."""
    if key not in DEFAULTS:
        return None, "unknown setting"
    kind = next((f[3] for f in FIELDS if f[0] == key), "text")
    raw = str(raw).strip()
    if kind == "bool":
        if raw.lower() in ("1", "true", "on"):
            return 1, None
        if raw.lower() in ("0", "false", "off", ""):
            return 0, None
        return None, "must be on or off"
    if kind == "int":
        try:
            val = int(float(raw))
        except ValueError:
            return None, "needs a number"
        if key in LIMITS:
            lo, hi = LIMITS[key]
            if not lo <= val <= hi:
                return None, f"allowed range {lo} to {hi}"
        return val, None
    if kind.startswith("choice:"):
        if raw not in kind[7:].split(","):
            return None, "allowed: " + kind[7:].replace(",", " or ")
        return raw, None
    if not raw or len(raw) > 120 or any(c in raw for c in "#=\n\r"):
        return None, "1 to 120 characters, without # and ="
    return raw, None
