#!/usr/bin/env python3
"""Mojave FPV LTE V1.8.1 - runs once at every boot (fpv-setup.service), as root.

1. Reads /boot/firmware/fpv-config.txt
2. Writes /etc/fpv/mediamtx.yml (video server settings) from it
3. Imports a WireGuard file dropped on the SD card as /boot/firmware/wg0.conf
"""
import glob
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fpvcfg  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.environ.get("FPV_ETC", "/etc/fpv")
BOOT_DIR = os.environ.get("FPV_BOOT", "/boot/firmware")
WG_DIR = os.environ.get("FPV_WG", "/etc/wireguard")


def log(msg):
    print(f"[fpv-setup] {msg}", flush=True)


def find_usb_mic():
    """First USB capture card as an ALSA name, e.g. plughw:CARD=C920,DEV=0."""
    try:
        out = subprocess.run(["arecord", "-l"], capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    for line in out.splitlines():
        m = re.match(r"card (\d+): (\S+) \[(.*?)\], device (\d+):", line)
        if m and "bcm2835" not in line.lower():
            return f"plughw:CARD={m.group(2)},DEV={m.group(4)}"
    return None


def have_webrtcdsp():
    """Is the noise filter (GStreamer element webrtcdsp, package gstreamer1.0-plugins-bad) installed?"""
    if os.environ.get("FPV_NO_SYSTEMCTL"):
        return os.environ.get("FPV_FAKE_DSP") == "1"
    try:
        r = subprocess.run(["timeout", "-s", "KILL", "10", "gst-launch-1.0", "-q", "audiotestsrc", "num-buffers=20", "!",
                            "audio/x-raw,rate=48000,channels=1,format=S16LE", "!", "webrtcdsp", "echo-cancel=false",
                            "!", "fakesink"], capture_output=True, timeout=14)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def audio_filter(cfg):
    """Pipeline part that cleans the microphone: rumble filter, noise suppression, automatic level."""
    if not int(cfg["audio_filter"]):
        return ""
    if have_webrtcdsp():
        level = {1: "low", 2: "moderate", 3: "high", 4: "very-high"}[int(cfg["audio_filter"])]
        return ("webrtcdsp echo-cancel=false high-pass-filter=true noise-suppression=true "
                f"noise-suppression-level={level} gain-control=true target-level-dbfs=6 compression-gain-db=12 limiter=true !")
    return "audiocheblimit mode=high-pass cutoff=120 poles=4 !"


def find_usb_cams():
    """All USB cameras (UVC). The CSI camera never shows up under by-id/usb-*."""
    return sorted(glob.glob("/dev/v4l/by-id/usb-*-video-index0"))


def best_mjpeg_size(dev, want_w, want_h):
    """Largest MJPEG picture size the camera offers that is not bigger than the wanted one."""
    try:
        out = subprocess.run(["v4l2-ctl", "-d", dev, "--list-formats-ext"], capture_output=True,
                             text=True, timeout=6).stdout
    except (OSError, subprocess.SubprocessError):
        return want_w, want_h
    sizes, in_mjpg = [], False
    for line in out.splitlines():
        m = re.search(r"\[\d+\]: '(\w+)'", line)
        if m:
            in_mjpg = m.group(1) == "MJPG"
        m = re.search(r"Size: Discrete (\d+)x(\d+)", line)
        if m and in_mjpg:
            sizes.append((int(m.group(1)), int(m.group(2))))
    if not sizes or (want_w, want_h) in sizes:
        return want_w, want_h
    fit = [s for s in sizes if s[0] <= want_w and s[1] <= want_h]
    return max(fit, key=lambda s: s[0] * s[1]) if fit else min(sizes, key=lambda s: s[0] * s[1])


def find_usb_cam():
    cams = find_usb_cams()
    return cams[0] if cams else None


def render_mediamtx(cfg):
    yn = lambda v: "true" if int(v) else "false"  # noqa: E731
    lines = [
        "# Written by apply_config.py at every boot - edit /boot/firmware/fpv-config.txt instead",
        "logLevel: info",
        "rtsp: yes",
        "rtspAddress: :8554",
        "rtmp: no",
        "hls: no",
        "srt: no",
        "webrtc: yes",
        "webrtcAddress: :8889",
        "webrtcLocalUDPAddress: :8189",
        "",
        "paths:",
        "  # Main camera, video only, lowest delay",
        "  cam:",
        "    source: rpiCamera",
        f"    rpiCameraWidth: {cfg['video_width']}",
        f"    rpiCameraHeight: {cfg['video_height']}",
        f"    rpiCameraFPS: {cfg['video_fps']}",
        f"    rpiCameraBitrate: {cfg['video_bitrate_kbps'] * 1000}",
        f"    rpiCameraIDRPeriod: {cfg['video_idr_period']}",
        f"    rpiCameraHFlip: {yn(cfg['video_hflip'])}",
        f"    rpiCameraVFlip: {yn(cfg['video_vflip'])}",
    ]
    notes = []

    if int(cfg["audio_enable"]):
        mic = cfg["audio_device"]
        if mic == "auto":
            mic = find_usb_mic()
        if mic:
            lines += [
                "",
                "  # Microphone sound on its own path, so it can be heard with every camera",
                "  mic:",
                "    runOnInit: >",
                f"      gst-launch-1.0 -q alsasrc device={mic} buffer-time=40000 latency-time=10000 !",
                "      audioconvert ! audioresample ! audio/x-raw,rate=48000,channels=1,format=S16LE !",
                f"      {audio_filter(cfg)}",
                f"      volume volume={float(cfg['audio_gain']):.1f} ! audioconvert !",
                f"      opusenc bitrate={cfg['audio_bitrate_kbps'] * 1000} audio-type=voice bandwidth=fullband frame-size=20 !",
                "      rtspclientsink location=rtsp://localhost:$RTSP_PORT/mic protocols=tcp latency=0",
                "    runOnInitRestart: yes",
            ]
            card = re.search(r"CARD=([^,]+)", mic)
            if card and not os.environ.get("FPV_NO_SYSTEMCTL"):     # microphone level of the camera to 100 %
                for ctl in ("Mic", "Capture"):
                    subprocess.run(["amixer", "-q", "-c", card.group(1), "sset", ctl, "100%", "cap"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            flt = audio_filter(cfg)
            notes.append(f"sound from {mic} on path 'mic', gain {cfg['audio_gain']}, {cfg['audio_bitrate_kbps']} kbit/s, "
                         + ("noise filter on" if flt.startswith("webrtcdsp") else "rumble filter only (noise filter not installed)" if flt else "no filter"))
        else:
            notes.append("audio_enable = 1 but no USB microphone found - path 'mic' not created")

    if int(cfg["cam2_enable"]):
        if cfg["cam2_device"] == "auto":
            devs = find_usb_cams()[:1]              # one USB camera -> cam2
        else:
            devs = [cfg["cam2_device"]]
        if not devs:
            notes.append("cam2_enable = 1 but no USB camera found - path 'cam2' not created")
        for n, dev in enumerate(devs, start=2):
            w, h = best_mjpeg_size(dev, int(cfg["cam2_width"]), int(cfg["cam2_height"]))
            lines += [
                "",
                f"  # USB camera {n - 1}, started only while somebody watches",
                f"  cam{n}:",
                "    runOnDemand: >",
                f"      /bin/bash {HERE}/usbcam.sh {dev} {w} {h} {cfg['cam2_fps']}",
                f"      {cfg['cam2_bitrate_kbps']} cam{n} {cfg['cam2_pipeline']}",
                "    runOnDemandRestart: yes",
                "    runOnDemandStartTimeout: 20s",
                "    runOnDemandCloseAfter: 10s",
            ]
            notes.append(f"USB camera {dev} on path 'cam{n}' with {w}x{h}")

    return "\n".join(lines) + "\n", notes


def clean_wireguard(text):
    """Make a FRITZ!Box WireGuard file safe for the car:
    - no DNS line (would need extra software on the Pi)
    - only private networks through the tunnel, the rest stays on LTE
    - keep-alive so the tunnel survives the mobile network"""
    out, in_peer, has_keepalive = [], False, False
    for line in text.splitlines():
        s = line.strip()
        low = s.lower()
        if s.startswith("["):
            in_peer = low == "[peer]"
        if low.startswith("dns"):
            continue
        if low.startswith("allowedips"):
            nets = [n.strip() for n in s.split("=", 1)[1].split(",")]
            keep = [n for n in nets if n not in ("0.0.0.0/0", "::/0") and ":" not in n]
            if not keep:
                keep = ["192.168.178.0/24"]
            line = "AllowedIPs = " + ", ".join(keep)
        if low.startswith("persistentkeepalive"):
            has_keepalive = True
            line = "PersistentKeepalive = 25"
        out.append(line)
    if not has_keepalive:
        out.append("PersistentKeepalive = 25")
    return "\n".join(out) + "\n"


def import_wireguard():
    src = os.path.join(BOOT_DIR, "wg0.conf")
    if not os.path.isfile(src):
        return
    with open(src, encoding="utf-8", errors="replace") as f:
        text = clean_wireguard(f.read())
    os.makedirs(WG_DIR, exist_ok=True)
    dst = os.path.join(WG_DIR, "wg0.conf")
    with open(dst, "w", encoding="utf-8") as f:
        f.write(text)
    os.chmod(dst, 0o600)
    os.replace(src, src + ".imported")
    log("WireGuard file imported -> /etc/wireguard/wg0.conf")
    if os.environ.get("FPV_NO_SYSTEMCTL"):
        return
    subprocess.run(["systemctl", "enable", "wg-quick@wg0"], check=False)
    subprocess.run(["systemctl", "restart", "wg-quick@wg0"], check=False)


def main():
    cfg, warnings = fpvcfg.load()
    log(f"Mojave FPV LTE {fpvcfg.VERSION}")
    for w in warnings:
        log(f"WARNING: {w}")
    text, notes = render_mediamtx(cfg)
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(os.path.join(OUT_DIR, "mediamtx.yml"), "w", encoding="utf-8") as f:
        f.write(text)
    log("video server settings written")
    for n in notes:
        log(n)
    import_wireguard()


if __name__ == "__main__":
    main()
