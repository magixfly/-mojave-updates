#!/usr/bin/env python3
"""Mojave FPV LTE V1.2 - runs once at every boot (fpv-setup.service), as root.

1. Reads /boot/firmware/fpv-config.txt
2. Writes /etc/fpv/mediamtx.yml (video server settings) from it
3. Imports a WireGuard file dropped on the SD card as /boot/firmware/wg0.conf
"""
import glob
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fpvcfg  # noqa: E402

OUT_DIR = os.environ.get("FPV_ETC", "/etc/fpv")
BOOT_DIR = os.environ.get("FPV_BOOT", "/boot/firmware")
WG_DIR = os.environ.get("FPV_WG", "/etc/wireguard")


def log(msg):
    print(f"[fpv-setup] {msg}", flush=True)


def find_usb_mic():
    """First USB capture card as an ALSA name, e.g. plughw:CARD=C920,DEV=0."""
    try:
        out = subprocess.run(["arecord", "-l"], capture_output=True, text=True, timeout=5).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    for line in out.splitlines():
        m = re.match(r"card (\d+): (\S+) \[(.*?)\], device (\d+):", line)
        if m and "bcm2835" not in line.lower():
            return f"plughw:CARD={m.group(2)},DEV={m.group(4)}"
    return None


def find_usb_cam():
    """First USB camera (UVC). The CSI camera never shows up under by-id/usb-*."""
    cams = sorted(glob.glob("/dev/v4l/by-id/usb-*-video-index0"))
    return cams[0] if cams else None


def render_mediamtx(cfg):
    yn = lambda v: "true" if int(v) else "false"  # noqa: E731
    lines = [
        "# Written by apply_config.py at every boot - edit /boot/firmware/fpv-config.txt instead",
        "logLevel: info",
        "rtsp: yes",
        "rtspAddress: :8554",
        "rtmp: no",
        "hls: no",
        "srt: no",
        "webrtc: yes",
        "webrtcAddress: :8889",
        "webrtcLocalUDPAddress: :8189",
        "",
        "paths:",
        "  # Main camera, video only, lowest delay",
        "  cam:",
        "    source: rpiCamera",
        f"    rpiCameraWidth: {cfg['video_width']}",
        f"    rpiCameraHeight: {cfg['video_height']}",
        f"    rpiCameraFPS: {cfg['video_fps']}",
        f"    rpiCameraBitrate: {cfg['video_bitrate_kbps'] * 1000}",
        f"    rpiCameraIDRPeriod: {cfg['video_idr_period']}",
        f"    rpiCameraHFlip: {yn(cfg['video_hflip'])}",
        f"    rpiCameraVFlip: {yn(cfg['video_vflip'])}",
    ]
    notes = []

    if int(cfg["audio_enable"]):
        mic = cfg["audio_device"]
        if mic == "auto":
            mic = find_usb_mic()
        if mic:
            lines += [
                "",
                "  # Main camera plus microphone sound",
                "  live:",
                "    runOnInit: >",
                "      gst-launch-1.0",
                "      rtspclientsink name=s location=rtsp://localhost:$RTSP_PORT/live",
                "      rtspsrc location=rtsp://127.0.0.1:$RTSP_PORT/cam latency=0 ! rtph264depay ! s.",
                f"      alsasrc device={mic} ! audioconvert ! audioresample !",
                f"      opusenc bitrate={cfg['audio_bitrate_kbps'] * 1000} ! s.",
                "    runOnInitRestart: yes",
            ]
            notes.append(f"sound from {mic} on path 'live'")
        else:
            notes.append("audio_enable = 1 but no USB microphone found - path 'live' not created")

    if int(cfg["cam2_enable"]):
        dev = cfg["cam2_device"]
        if dev == "auto":
            dev = find_usb_cam()
        if dev:
            lines += [
                "",
                "  # Second camera (USB), started only while somebody watches",
                "  cam2:",
                "    runOnDemand: >",
                "      ffmpeg -hide_banner -loglevel warning",
                f"      -f v4l2 -input_format mjpeg -video_size {cfg['cam2_width']}x{cfg['cam2_height']}",
                f"      -framerate {cfg['cam2_fps']} -i {dev}",
                f"      -pix_fmt yuv420p -c:v h264_v4l2m2m -b:v {cfg['cam2_bitrate_kbps']}k -g {cfg['cam2_fps']}",
                "      -f rtsp rtsp://localhost:$RTSP_PORT/cam2",
                "    runOnDemandRestart: yes",
                "    runOnDemandCloseAfter: 10s",
            ]
            notes.append(f"second camera {dev} on path 'cam2'")
        else:
            notes.append("cam2_enable = 1 but no USB camera found - path 'cam2' not created")

    return "\n".join(lines) + "\n", notes


def clean_wireguard(text):
    """Make a FRITZ!Box WireGuard file safe for the car:
    - no DNS line (would need extra software on the Pi)
    - only private networks through the tunnel, the rest stays on LTE
    - keep-alive so the tunnel survives the mobile network"""
    out, in_peer, has_keepalive = [], False, False
    for line in text.splitlines():
        s = line.strip()
        low = s.lower()
        if s.startswith("["):
            in_peer = low == "[peer]"
        if low.startswith("dns"):
            continue
        if low.startswith("allowedips"):
            nets = [n.strip() for n in s.split("=", 1)[1].split(",")]
            keep = [n for n in nets if n not in ("0.0.0.0/0", "::/0") and ":" not in n]
            if not keep:
                keep = ["192.168.178.0/24"]
            line = "AllowedIPs = " + ", ".join(keep)
        if low.startswith("persistentkeepalive"):
            has_keepalive = True
            line = "PersistentKeepalive = 25"
        out.append(line)
    if not has_keepalive:
        out.append("PersistentKeepalive = 25")
    return "\n".join(out) + "\n"


def import_wireguard():
    src = os.path.join(BOOT_DIR, "wg0.conf")
    if not os.path.isfile(src):
        return
    with open(src, encoding="utf-8", errors="replace") as f:
        text = clean_wireguard(f.read())
    os.makedirs(WG_DIR, exist_ok=True)
    dst = os.path.join(WG_DIR, "wg0.conf")
    with open(dst, "w", encoding="utf-8") as f:
        f.write(text)
    os.chmod(dst, 0o600)
    os.replace(src, src + ".imported")
    log("WireGuard file imported -> /etc/wireguard/wg0.conf")
    if os.environ.get("FPV_NO_SYSTEMCTL"):
        return
    subprocess.run(["systemctl", "enable", "wg-quick@wg0"], check=False)
    subprocess.run(["systemctl", "restart", "wg-quick@wg0"], check=False)


def main():
    cfg, warnings = fpvcfg.load()
    log(f"Mojave FPV LTE {fpvcfg.VERSION}")
    for w in warnings:
        log(f"WARNING: {w}")
    text, notes = render_mediamtx(cfg)
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(os.path.join(OUT_DIR, "mediamtx.yml"), "w", encoding="utf-8") as f:
        f.write(text)
    log("video server settings written")
    for n in notes:
        log(n)
    import_wireguard()


if __name__ == "__main__":
    main()
