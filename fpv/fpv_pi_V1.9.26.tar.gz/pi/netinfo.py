#!/usr/bin/env python3
"""How the Pi reaches the internet right now: Wi-Fi (with its name), the LTE stick or cable.

Looks at the default route (the way with the lowest metric wins) every few seconds.
Result, e.g.: {"kind": "wifi", "name": "Optimus Prime", "sig": -52, "dev": "wlan0", "other": "lte",
               "wifi_on": True, "lte_up": True}
  kind:    wifi | lte | lan | none
  other:   a second way that is up but not used at the moment (or "")
  wifi_on: the Pi's Wi-Fi is switched on (False = "4G only")
  lte_up:  the LTE stick offers a way to the internet

"4G only" (set_wifi(False)) switches the Pi's Wi-Fi off, so that no hotspot or home network in
reach can take over. It is refused while the stick is not online, and it is taken back by itself
when the stick has been gone for GRACE seconds - the Pi must never lock itself out.
"""
import os
import subprocess
import threading
import time

INFO = {"kind": "none", "name": "", "sig": None, "dev": "", "other": "", "wifi_on": None, "lte_up": False}
GRACE = float(os.environ.get("FPV_NET_GRACE", "60"))   # s without the stick before Wi-Fi comes back
_lost_since = None


def _run(*cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=4).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def _kind(dev):
    base = "/sys/class/net/" + dev
    if os.path.isdir(base + "/wireless") or dev.startswith("wl"):
        return "wifi"
    try:
        if "/usb" in os.path.realpath(base + "/device"):     # a network card on USB = the LTE stick
            return "lte"
    except OSError:
        pass
    if dev.startswith(("wwan", "usb", "ppp")):
        return "lte"
    return "lan"


def _ssid(dev):
    name = _run("iwgetid", "-r", dev).strip()
    if not name:
        for line in _run("nmcli", "-t", "-f", "ACTIVE,SSID", "dev", "wifi").splitlines():
            if line.startswith(("yes:", "ja:")):
                name = line.split(":", 1)[1].replace("\\:", ":")
                break
    return name


def _signal(dev):
    try:
        for line in open("/proc/net/wireless"):
            if line.strip().startswith(dev + ":"):
                return int(float(line.split()[3]))
    except (OSError, ValueError, IndexError):
        pass
    return None


def parse_routes(text):
    """[(metric, dev)] of all default routes, best first."""
    out = []
    for line in text.splitlines():
        p = line.split()
        if not p or p[0] != "default" or "dev" not in p:
            continue
        dev = p[p.index("dev") + 1]
        metric = int(p[p.index("metric") + 1]) if "metric" in p else 0
        out.append((metric, dev))
    return sorted(out)


def wifi_on():
    """True / False, None if it cannot be read."""
    s = _run("nmcli", "radio", "wifi").strip().lower()
    return True if s == "enabled" else False if s == "disabled" else None


def read():
    routes = parse_routes(_run("ip", "-4", "route", "show", "default"))
    kinds = [_kind(d) for _, d in routes]
    info = {"kind": "none", "name": "", "sig": None, "dev": "", "other": "",
            "wifi_on": wifi_on(), "lte_up": "lte" in kinds}
    if not routes:
        return info
    dev, kind = routes[0][1], kinds[0]
    others = [k for k in kinds[1:] if k != kind]
    info.update(kind=kind, dev=dev, other=others[0] if others else "")
    if kind == "wifi":
        info["name"], info["sig"] = _ssid(dev), _signal(dev)
    return info


def set_wifi(on):
    """Switches the Pi's Wi-Fi on or off. Returns (ok, message)."""
    if not on:
        now = read()
        if not now["lte_up"]:
            return False, "The LTE stick is not online - Wi-Fi stays on, otherwise the Pi would be unreachable"
    r = subprocess.run(["nmcli", "radio", "wifi", "on" if on else "off"], capture_output=True, text=True, timeout=10)
    if r.returncode != 0:
        return False, (r.stderr or r.stdout).strip()[:200] or "nmcli failed"
    time.sleep(1.5 if on else 0.5)
    INFO.update(read())
    print(f"[net] Wi-Fi switched {'on' if on else 'off (4G only)'}", flush=True)
    return True, ""


def _watch(info):
    """4G only, but the stick is gone: after GRACE seconds Wi-Fi is switched on again."""
    global _lost_since
    if info["wifi_on"] is False and not info["lte_up"]:
        _lost_since = _lost_since or time.monotonic()
        if time.monotonic() - _lost_since >= GRACE:
            print("[net] 4G only, but the LTE stick is gone - Wi-Fi switched on again", flush=True)
            subprocess.run(["nmcli", "radio", "wifi", "on"], capture_output=True, timeout=10)
            _lost_since = None
    else:
        _lost_since = None


def _loop():
    while True:
        try:
            info = read()
            INFO.update(info)
            _watch(info)
        except Exception as e:                       # never let this thread die
            print(f"[net] {e}", flush=True)
        time.sleep(5)


def start():
    threading.Thread(target=_loop, daemon=True).start()


def add_routes(app, web):
    import asyncio

    async def get_net(_req):
        return web.json_response(INFO)

    async def post_net(req):
        if req.headers.get("X-FPV") != "1":
            return web.json_response({"ok": False, "error": "missing header"}, status=403)
        try:
            data = await req.json()
        except ValueError:
            data = {}
        if not isinstance(data.get("wifi"), bool):
            return web.json_response({"ok": False, "error": "wifi: true or false expected"}, status=400)
        ok, msg = await asyncio.get_running_loop().run_in_executor(None, set_wifi, data["wifi"])
        return web.json_response({"ok": ok, "error": msg, **INFO})

    app.add_routes([web.get("/api/net", get_net), web.post("/api/net", post_net)])


if __name__ == "__main__":
    print(read())
