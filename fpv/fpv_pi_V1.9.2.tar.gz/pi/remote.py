#!/usr/bin/env python3
"""Mojave FPV LTE V1.9.2 - remote maintenance over GitHub (runs as root, fpv-remote.service).

Same idea as the Core Tracker and the Carlin box:
  commands  : branch "carlin", folder fpvin/NNN_name.sh   (bash, run exactly once, as root)
  results   : folder fpvout/NNN_name.log                   (needs a GitHub token on the Pi)
  heartbeat : fpvout/status.txt every 10 minutes           (needs the token too)

Without a token the Pi still fetches and runs commands (the repository is public), the
results then stay on the Pi and are shown on the settings page (Remote maintenance).

Settings: /boot/firmware/fpv-remote.txt (name = value), token in /etc/fpv/github-token.
"""
import base64
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fpvcfg  # noqa: E402

DEFAULTS = {"remote_enable": "1", "repo": "magixfly/-mojave-updates", "branch": "carlin",
            "in_dir": "fpvin", "out_dir": "fpvout", "poll_s": "30", "poll_no_token_s": "90",
            "heartbeat_min": "10", "cmd_timeout_s": "600"}
CONF = os.environ.get("FPV_REMOTE_CONF", "/boot/firmware/fpv-remote.txt")
TOKEN = os.environ.get("FPV_REMOTE_TOKEN", "/etc/fpv/github-token")
STATE_DIR = os.environ.get("FPV_REMOTE_STATE", "/var/lib/fpv-remote")
STATUS = os.environ.get("FPV_REMOTE_STATUS", "/run/fpv-remote.json")
API = os.environ.get("FPV_REMOTE_API", "https://api.github.com")
MAX_LOG = 200_000


def log(msg):
    print(f"[fpv-remote] {msg}", flush=True)


def load_conf():
    c = dict(DEFAULTS)
    try:
        with open(CONF, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if "=" in line:
                    k, v = [s.strip() for s in line.split("=", 1)]
                    if k in c and v:
                        c[k] = v
    except OSError:
        pass
    return c


def read_token():
    try:
        with open(TOKEN, encoding="utf-8") as f:
            t = f.read().strip()
        return t or None
    except OSError:
        return None


def request(method, url, token=None, body=None, etag=None, timeout=25):
    """Returns (http status, parsed JSON or raw bytes, etag)."""
    headers = {"User-Agent": "mojave-fpv-remote", "Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    if etag:
        headers["If-None-Match"] = etag
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            try:
                return r.status, json.loads(raw), r.headers.get("ETag")
            except ValueError:
                return r.status, raw, r.headers.get("ETag")
    except urllib.error.HTTPError as e:
        return e.code, None, None


class State:
    def __init__(self):
        os.makedirs(os.path.join(STATE_DIR, "out"), exist_ok=True)
        self.path = os.path.join(STATE_DIR, "state.json")
        self.d = {"done": None, "uploaded": []}
        try:
            with open(self.path, encoding="utf-8") as f:
                self.d.update(json.load(f))
        except (OSError, ValueError):
            pass

    def save(self):
        tmp = self.path + ".new"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.d, f)
        os.replace(tmp, self.path)


def out_path(name):
    return os.path.join(STATE_DIR, "out", name + ".log")


def run_command(name, script, timeout_s):
    path = os.path.join(STATE_DIR, name + ".sh")
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(script.replace("\r\n", "\n"))
    head = f"== {name} on {os.uname().nodename}, {time.strftime('%F %T')}, FPV {fpvcfg.VERSION} ==\n"
    t0 = time.time()
    try:
        p = subprocess.run(["bash", path], capture_output=True, timeout=timeout_s,
                           cwd="/root" if os.path.isdir("/root") and os.access("/root", os.W_OK)
                           else STATE_DIR,
                           env={**os.environ, "HOME": "/root", "DEBIAN_FRONTEND": "noninteractive",
                                "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"})
        body = (p.stdout + p.stderr).decode("utf-8", "replace")
        tail = f"\n== exit code {p.returncode}, {time.time() - t0:.1f} s ==\n"
    except subprocess.TimeoutExpired as e:
        body = ((e.stdout or b"") + (e.stderr or b"")).decode("utf-8", "replace")
        tail = f"\n== STOPPED after {timeout_s} s (time limit) ==\n"
    if len(body) > MAX_LOG:
        body = body[:MAX_LOG // 2] + "\n... (middle cut) ...\n" + body[-MAX_LOG // 2:]
    text = head + body + tail
    with open(out_path(name), "w", encoding="utf-8") as f:
        f.write(text)
    return text


def upload(conf, token, rel, text, message):
    """Create or replace one file in the out folder. True on success."""
    url = f"{API}/repos/{conf['repo']}/contents/{conf['out_dir']}/{rel}"
    for _ in range(3):
        code, cur, _ = request("GET", url + "?ref=" + conf["branch"], token)
        body = {"message": message, "branch": conf["branch"],
                "content": base64.b64encode(text.encode()).decode()}
        if code == 200 and isinstance(cur, dict) and cur.get("sha"):
            body["sha"] = cur["sha"]
        code, _, _ = request("PUT", url, token, body)
        if code in (200, 201):
            return True
        if code in (401, 403, 404):
            return False
        time.sleep(2)
    return False


def sh(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=8).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def heartbeat_text(extra):
    temp = ""
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            temp = f"{int(f.read()) / 1000:.1f} C"
    except (OSError, ValueError):
        pass
    lines = [f"mojave-fpv remote maintenance, FPV {fpvcfg.VERSION}",
             f"time      {time.strftime('%F %T %Z')}",
             f"uptime    {sh(['uptime', '-p'])}",
             f"addresses {sh(['hostname', '-I'])}",
             f"wifi      {sh(['iwgetid', '-r'])}",
             f"tailscale {sh(['tailscale', 'ip', '-4']) or 'not installed / not logged in'}",
             f"temp      {temp}",
             f"throttled {sh(['vcgencmd', 'get_throttled'])}",
             f"services  video={sh(['systemctl', 'is-active', 'fpv-mediamtx'])} "
             f"bridge={sh(['systemctl', 'is-active', 'fpv-bridge'])}",
             f"last      {extra}"]
    return "\n".join(lines) + "\n"


def write_status(**kw):
    try:
        tmp = STATUS + ".new"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(kw, f)
        os.replace(tmp, STATUS)
    except OSError:
        pass


def cycle(conf, st, token, mem):
    """One poll. mem keeps the ETag and the cached listing between polls."""
    url = f"{API}/repos/{conf['repo']}/contents/{conf['in_dir']}?ref={conf['branch']}"
    code, data, etag = request("GET", url, token, etag=mem.get("etag"))
    if code == 304:
        data = mem.get("list", [])
    elif code == 200 and isinstance(data, list):
        mem["etag"], mem["list"] = etag, data
    elif code == 401:
        return "GitHub refused the token (wrong or expired)"
    elif code in (403, 429):
        return "GitHub rate limit - waiting"
    else:
        return f"GitHub answered {code}"
    names = sorted(i["name"][:-3] for i in data
                   if i.get("type") == "file" and re.fullmatch(r"\d{3,}_[\w.-]+\.sh", i.get("name", "")))
    urls = {i["name"][:-3]: i.get("download_url") for i in data if i.get("type") == "file"}
    if st.d["done"] is None:                     # very first start: old commands are not run
        st.d["done"] = names
        st.save()
        log(f"first start - {len(names)} existing commands marked as done")
        return None
    for name in names:
        if name in st.d["done"]:
            continue
        code, raw, _ = request("GET", urls[name], token=None)
        if code != 200 or raw is None:
            return f"could not download {name}"
        script = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else json.dumps(raw)
        m = re.search(r"^#timeout\s+(\d+)", script, re.M)
        limit = min(3600, int(m.group(1))) if m else int(conf["cmd_timeout_s"])
        st.d["done"].append(name)                # mark first: a command that reboots must not loop
        st.save()
        log(f"running {name}")
        mem["last_cmd"] = f"{name} at {time.strftime('%F %T')}"
        write_status(ok=True, running=name, **mem_public(mem, token))
        run_command(name, script, limit)
        log(f"{name} finished")
    if token:                                    # upload results that are not on GitHub yet
        for name in st.d["done"]:
            if name in st.d["uploaded"] or not os.path.isfile(out_path(name)):
                continue
            with open(out_path(name), encoding="utf-8", errors="replace") as f:
                text = f.read()
            if upload(conf, token, name + ".log", text, f"fpv result {name}"):
                st.d["uploaded"].append(name)
                st.save()
            else:
                return f"could not upload the result of {name} (token without write access?)"
    return None


def mem_public(mem, token):
    return {"last_cmd": mem.get("last_cmd"), "token": bool(token), "version": fpvcfg.VERSION}


def main():
    st, mem, last_beat = State(), {}, 0.0
    log(f"Mojave FPV LTE {fpvcfg.VERSION} remote maintenance")
    while True:
        conf, token = load_conf(), read_token()
        if conf["remote_enable"] != "1":
            write_status(ok=True, enabled=False, t=time.time(), **mem_public(mem, token))
            time.sleep(30)
            continue
        try:
            err = cycle(conf, st, token, mem)
        except Exception as e:                   # no internet, DNS ...
            err = f"no connection to GitHub ({type(e).__name__})"
        if not err and token and time.time() - last_beat > int(conf["heartbeat_min"]) * 60:
            try:
                if upload(conf, token, "status.txt", heartbeat_text(mem.get("last_cmd") or "-"),
                          "fpv status"):
                    last_beat = time.time()
            except Exception:
                pass
        write_status(ok=not err, enabled=True, error=err, t=time.time(), running=None,
                     **mem_public(mem, token))
        if err:
            log(err)
        time.sleep(int(conf["poll_s"]) if token else int(conf["poll_no_token_s"]))


if __name__ == "__main__":
    main()
