#!/usr/bin/env python3
"""Mojave FPV LTE V1.9.29 - results of the latency test in the cockpit.

The cockpit measures glass-to-glass delay (screen flashes, the car camera films the screen, the cockpit
finds the flash in the received picture) and sends the result here. Kept in /var/lib/fpv/latency.jsonl
(last 200 tests) so they can be compared later, also through remote maintenance.

Routes: GET /api/latency (last 50), POST /api/latency (one result, header X-FPV: 1).
"""
import json
import os
import time

FILE = os.environ.get("FPV_LATLOG", "/var/lib/fpv/latency.jsonl")
KEEP = 200


def read(n=50):
    try:
        with open(FILE) as f:
            rows = [json.loads(x) for x in f if x.strip()]
    except (OSError, ValueError):
        return []
    return rows[-n:]


def add(row):
    rows = read(KEEP - 1) + [row]
    os.makedirs(os.path.dirname(FILE), exist_ok=True)
    with open(FILE + ".tmp", "w") as f:
        f.write("".join(json.dumps(r, separators=(",", ":")) + "\n" for r in rows))
    os.replace(FILE + ".tmp", FILE)


def add_routes(app, web, extra=None):
    async def get_lat(_req):
        return web.json_response(read())

    async def post_lat(req):
        if req.headers.get("X-FPV") != "1":
            return web.json_response({"ok": False}, status=403)
        try:
            d = await req.json()
        except ValueError:
            return web.json_response({"ok": False, "error": "no data"})
        row = {k: d[k] for k in list(d)[:40] if isinstance(d[k], (int, float, str, bool, type(None), list))}
        row["at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        if extra:
            try:
                row.update(extra())
            except Exception:
                pass
        add(row)
        return web.json_response({"ok": True})

    app.add_routes([web.get("/api/latency", get_lat), web.post("/api/latency", post_lat)])
