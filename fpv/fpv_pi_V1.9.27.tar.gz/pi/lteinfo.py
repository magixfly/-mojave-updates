#!/usr/bin/env python3
"""Mojave FPV LTE V1.9.27 - signal values of the LTE stick (Hoco HI43, Marvell "duster" web page).

The stick shows its values only after a login (HTTP digest, like its own web page does it).
User name and password are typed in by the user in the cockpit and kept in /etc/fpv/stick-login
(readable for root only). They never appear in a status message, a log or a recording.

Every 2 s the Pi asks the stick for its status file and keeps only signal values:
  INFO = {"state": "ok", "dbm": -97, "rsrp": -97, "rsrq": -11, "sinr": 12, "rssi": ..., "band": "3",
          "mode": "LTE", "op": "A1", "roam": False, "at": <unix time>}
  state: no_stick | no_login | login_failed | kicked | ok | error
  dbm:   the one number shown in the cockpit (RSRP if the stick reports it, else RSSI in dBm)

Routes: GET /api/lte (values), GET /api/lte/tags (names of the values the stick offers, for finding
new ones), POST /api/lte/login {"user", "pass"} with header X-FPV: 1 (empty pass = forget the login).
"""
import hashlib
import json
import os
import random
import re
import subprocess
import threading
import time
import urllib.error
import urllib.request

LOGIN_FILE = os.environ.get("FPV_STICK_LOGIN", "/etc/fpv/stick-login")
HOST_FIX = os.environ.get("FPV_STICK_HOST", "")          # tests: "127.0.0.1:18080"
PERIOD = 2.0
INFO = {"state": "no_stick", "dbm": None, "at": 0}
TAGS = {}                                                 # file -> [tag names]
SIGNAL = re.compile(r"(rssi|rsrp|rsrq|sinr|snr|rscp|ecio|band|earfcn|pci|cell_?id|sys_mode|sys_submode|"
                    r"network_name|roaming|signal|network_type|mcc|mnc|tac|bar)", re.I)
SECRET = re.compile(r"(pass|key|imei|imsi|iccid|^sn$|ssid|apn|user|pin|puk|mac|ip$|dns)", re.I)
CANDIDATES = ["status1", "wan", "lte_status", "network_info", "cell_info", "eng_mode", "engineer_mode",
              "neighbor_cell", "signal", "ui_status", "statistics"]
_lock = threading.Lock()
_s = {"nonce": "", "realm": "", "qop": "auth", "nc": 1, "logged": False, "fails": 0, "wait_until": 0.0,
      "files": ["status1"], "probed": False, "login_at": 0.0}


def _md5(t):
    return hashlib.md5(t.encode()).hexdigest()


def _cnonce():
    return _md5(f"{random.randint(0, 100000)}{int(time.time() * 1000)}")[:16]


def load_login():
    try:
        with open(LOGIN_FILE) as f:
            d = json.load(f)
        if d.get("pass"):
            return str(d.get("user") or "admin"), str(d["pass"])
    except (OSError, ValueError):
        pass
    return None


def save_login(user, pw):
    os.makedirs(os.path.dirname(LOGIN_FILE), exist_ok=True)
    if not pw:
        try:
            os.remove(LOGIN_FILE)
        except OSError:
            pass
    else:
        fd = os.open(LOGIN_FILE + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump({"user": user or "admin", "pass": pw}, f)
        os.replace(LOGIN_FILE + ".tmp", LOGIN_FILE)
    with _lock:
        _s.update(logged=False, fails=0, wait_until=0.0, probed=False, files=["status1"])
    TAGS.clear()


def stick_host():
    if HOST_FIX:
        return HOST_FIX
    try:
        out = subprocess.run(["ip", "-4", "route", "show", "default"], capture_output=True, text=True, timeout=3).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    for line in out.splitlines():
        p = line.split()
        if "via" in p and "dev" in p:
            dev = p[p.index("dev") + 1]
            try:
                usb = "/usb" in os.path.realpath(f"/sys/class/net/{dev}/device")
            except OSError:
                usb = False
            if usb or dev.startswith(("usb", "wwan")):
                return p[p.index("via") + 1]
    return None


def _get(host, path, auth=None, timeout=3):
    req = urllib.request.Request(f"http://{host}{path}")
    if auth:
        req.add_header("Authorization", auth)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, dict(r.headers), r.read(200000).decode("ascii", "replace")
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), ""


def _param(header, name):
    m = re.search(name + r'="?([^",]+)"?', header or "")
    return m.group(1) if m else ""


def login(host, user, pw):
    """Digest login exactly like the stick's own page (utils.js doLogin)."""
    _st, hdr, _ = _get(host, "/login.cgi")
    www = hdr.get("WWW-Authenticate") or hdr.get("Www-Authenticate") or ""
    realm, nonce, qop = _param(www, "realm"), _param(www, "nonce"), _param(www, "qop") or "auth"
    if not nonce:
        raise RuntimeError("the stick sent no login challenge")
    cn = _cnonce()
    ha1 = _md5(f"{user}:{realm}:{pw}")
    ha2 = _md5("GET:/cgi/protected.cgi")
    resp = _md5(f"{ha1}:{nonce}:00000001:{cn}:{qop}:{ha2}")
    q = (f"/login.cgi?Action=Digest&username={urllib.request.quote(user)}&realm={urllib.request.quote(realm)}"
         f"&nonce={nonce}&response={resp}&qop={qop}&cnonce={cn}&temp=asr")
    st, _, _ = _get(host, q)
    with _lock:
        _s.update(nonce=nonce, realm=realm, qop=qop, nc=2, login_at=time.time())
    return st == 200


def _auth(user, pw):
    with _lock:
        nc = f"{_s['nc']:08x}"
        _s["nc"] += 1
        realm, nonce, qop = _s["realm"], _s["nonce"], _s["qop"]
    cn = _cnonce()
    ha1 = _md5(f"{user}:{realm}:{pw}")
    ha2 = _md5("GET:/cgi/xml_action.cgi")
    resp = _md5(f"{ha1}:{nonce}:{nc}:{cn}:{qop}:{ha2}")
    return (f'Digest username="{user}", realm="{realm}", nonce="{nonce}", uri="/cgi/xml_action.cgi", '
            f'response="{resp}", qop={qop}, nc={nc}, cnonce="{cn}"')


def get_file(host, user, pw, name):
    """Returns (login_status, {tag: text}) of one xml file of the stick."""
    st, _, body = _get(host, f"/xml_action.cgi?method=get&module=duster&file={name}", _auth(user, pw))
    m = re.search(r"<login_status>([^<]*)</login_status>", body)
    ls = m.group(1) if m else ""
    if st != 200 or not body:
        return "HTTP" + str(st), {}
    vals = {}
    for tag, text in re.findall(r"<([A-Za-z_][\w\-]*)>([^<>]*)</\1>", body):
        vals.setdefault(tag, text.strip())
    return ls, vals


def _num(v):
    try:
        return float(re.findall(r"-?\d+(?:\.\d+)?", v)[0])
    except (IndexError, ValueError, TypeError):
        return None


SYS_MODE = {"0": "No service", "1": "AMPS", "2": "CDMA", "3": "GSM", "4": "HDR", "5": "WCDMA", "6": "GPS",
            "8": "GSM/WCDMA", "9": "CDMA/HDR", "15": "TD-SCDMA", "17": "LTE"}


def pick(vals):
    """From all values of the stick: only signal values, in a fixed short form."""
    keep = {k: v for k, v in vals.items() if SIGNAL.search(k) and not SECRET.search(k) and len(v) <= 24}
    low = {k.lower(): v for k, v in keep.items()}
    out = {"raw": keep}

    def first(*names):
        for n in names:
            for k, v in low.items():
                if (k == n or k.endswith("_" + n) or k.startswith(n)) and v != "":
                    return v
        return None
    for key, names in (("rsrp", ("rsrp",)), ("rsrq", ("rsrq",)), ("sinr", ("sinr", "snr")), ("rssi", ("rssi",))):
        n = _num(first(*names))
        out[key] = int(n) if n is not None and n.is_integer() else n
    b = first("band", "lte_band")
    out["band"] = b
    sm = first("sys_mode")
    out["mode"] = SYS_MODE.get(sm, sm) if sm is not None else first("network_type")
    out["op"] = first("network_name", "operator_name")
    r = first("roaming")
    out["roam"] = None if r is None else r not in ("0", "", "false")
    dbm = out["rsrp"] if isinstance(out["rsrp"], (int, float)) and out["rsrp"] < 0 else None
    rs = out["rssi"]
    if dbm is None and isinstance(rs, (int, float)):
        dbm = rs if rs < 0 else (-113 + 2 * rs if 5 < rs <= 31 else None)     # 6..31 = AT+CSQ scale, 0..5 = bars
    out["dbm"] = dbm
    out["bars"] = int(rs) if isinstance(rs, (int, float)) and 0 <= rs <= 5 else None
    return out


def _probe(host, user, pw):
    """Once after a login: which files does the stick offer, which tags are in them."""
    names = list(CANDIDATES)
    try:
        _st, _, idx = _get(host, "/", timeout=4)
        for js in re.findall(r'src="(js/panel/[^"]+\.js)"', idx)[:40]:
            _st, _, code = _get(host, "/" + js, timeout=4)
            names += re.findall(r"file=([a-z][a-z0-9_]{2,30})", code)
    except Exception:
        pass
    seen, files = [], ["status1"]
    for n in names:
        if n in seen or len(seen) >= 40:
            continue
        seen.append(n)
        try:
            ls, vals = get_file(host, user, pw, n)
        except Exception:
            continue
        if ls in ("UNAUTHORIZED", "KICKOFF") or not vals:
            continue
        TAGS[n] = sorted(vals)[:120]
        if n != "status1" and any(re.search(r"rsrp|rsrq|sinr|snr", k, re.I) for k in vals) and len(files) < 3:
            files.append(n)
    with _lock:
        _s.update(files=files, probed=True)


def step():
    host = stick_host()
    if not host:
        return {"state": "no_stick"}
    cred = load_login()
    if not cred:
        return {"state": "no_login"}
    user, pw = cred
    now = time.time()
    if now < _s["wait_until"]:
        return {"state": INFO.get("state") if INFO.get("state") in ("login_failed", "kicked") else "error"}
    if not _s["logged"]:
        ok = login(host, user, pw)
        ls, vals = get_file(host, user, pw, "status1") if ok else ("UNAUTHORIZED", {})
        if not ok or ls == "UNAUTHORIZED" or not vals:
            _s["fails"] += 1
            _s["wait_until"] = now + (30 if _s["fails"] < 3 else 600)      # never hammer the stick with wrong passwords
            return {"state": "login_failed"}
        _s.update(logged=True, fails=0)
        if not _s["probed"]:
            _probe(host, user, pw)
    merged = {}
    for name in list(_s["files"]):
        ls, vals = get_file(host, user, pw, name)
        if ls == "KICKOFF":                       # somebody logged in on the stick page: leave them alone for a minute
            _s.update(logged=False, wait_until=now + 60)
            return {"state": "kicked"}
        if ls == "UNAUTHORIZED" or (name == "status1" and not vals):
            _s["logged"] = False
            return {"state": "error"}
        merged.update(vals)
    out = pick(merged)
    out["state"] = "ok"
    return out


def _loop():
    while True:
        try:
            r = step()
        except Exception as e:
            print(f"[lte] {type(e).__name__}: {e}", flush=True)
            _s["logged"] = False
            r = {"state": "error"}
        r["at"] = int(time.time())
        if r["state"] != "ok":
            r["dbm"] = None
        if r["state"] != INFO.get("state"):
            print(f"[lte] {r['state']}", flush=True)
        INFO.clear()
        INFO.update(r)
        time.sleep(PERIOD)


def public():
    """For status messages and recordings: short, without the raw list."""
    return {k: v for k, v in INFO.items() if k != "raw" and v is not None}


def start():
    threading.Thread(target=_loop, daemon=True).start()


def add_routes(app, web):
    import asyncio

    async def get_lte(_req):
        return web.json_response({**INFO, "login": load_login() is not None,
                                  "user": (load_login() or ("admin", ""))[0]})

    async def get_tags(_req):
        return web.json_response({"files": _s["files"], "tags": TAGS})

    async def post_login(req):
        if req.headers.get("X-FPV") != "1":
            return web.json_response({"ok": False, "error": "missing header"}, status=403)
        try:
            data = await req.json()
        except ValueError:
            data = {}
        user = str(data.get("user") or "admin").strip()[:32]
        pw = str(data.get("pass") or "")[:64]
        if not re.fullmatch(r"[\w.\-@]+", user):
            return web.json_response({"ok": False, "error": "user name: letters and numbers only"})
        try:
            await asyncio.get_running_loop().run_in_executor(None, save_login, user, pw)
        except OSError as e:
            return web.json_response({"ok": False, "error": f"could not store: {e}"})
        print("[lte] login " + ("stored" if pw else "removed"), flush=True)
        return web.json_response({"ok": True, "login": bool(pw)})

    app.add_routes([web.get("/api/lte", get_lte), web.get("/api/lte/tags", get_tags),
                    web.post("/api/lte/login", post_login)])


if __name__ == "__main__":
    print(json.dumps(step(), indent=1))
