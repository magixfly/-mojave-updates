#!/usr/bin/env python3
"""Mojave FPV LTE V1.5.3 - telemetry and control bridge.

- Talks MSP (the INAV data protocol) to the flight controller on the GPIO UART
- Serves the cockpit web page and pushes live values over a WebSocket
- Optional: steers over IP through INAV "MSP RC OVERRIDE" while the ELRS link is weak

Safety rules built in:
- Control over IP is OFF unless control_enable = 1 in fpv-config.txt
- It only works while the INAV mode MSP RC OVERRIDE is switched on at the transmitter
- No fresh command from the ground -> 5 x neutral, then the Pi stops sending
- Throttle over IP is limited by throttle_limit_pct
"""
import asyncio
import json
import os
import struct
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fpvcfg  # noqa: E402

MSP_RX_MAP = 64
MSP_STATUS = 101
MSP_RC = 105
MSP_RAW_GPS = 106
MSP_ATTITUDE = 108
MSP_ANALOG = 110
MSP_BOXIDS = 119
MSP_SET_RAW_RC = 200

BOX_ARM = 0
BOX_MSP_RC_OVERRIDE = 50   # INAV permanent box id of the mode "MSP RC OVERRIDE"
TICK_S = 0.04              # 25 control steps per second
NEUTRAL_BURST = 5
AXIS_INDEX = {"roll": 0, "pitch": 1, "yaw": 2, "throttle": 3}


# ----------------------------------------------------------------- MSP v1

def msp_encode(cmd, payload=b""):
    body = bytes([len(payload), cmd]) + payload
    crc = 0
    for b in body:
        crc ^= b
    return b"$M<" + body + bytes([crc])


class MspPort:
    """Request/response MSP v1 over a serial port (anything with read/write)."""

    def __init__(self, ser):
        self.ser = ser

    def request(self, cmd, payload=b"", timeout=0.12):
        try:
            self.ser.reset_input_buffer()
        except Exception:
            pass
        self.ser.write(msp_encode(cmd, payload))
        end = time.monotonic() + timeout
        buf = bytearray()
        while time.monotonic() < end:
            chunk = self.ser.read(64)
            if chunk:
                buf += chunk
                res = self._parse(buf, cmd)
                if res is not None:
                    return res
        return None

    @staticmethod
    def _parse(buf, cmd):
        i = buf.find(b"$M")
        while i >= 0:
            if len(buf) < i + 5:
                return None
            direction, size, rcmd = buf[i + 2], buf[i + 3], buf[i + 4]
            if len(buf) < i + 6 + size:
                return None
            payload = bytes(buf[i + 5:i + 5 + size])
            crc = size ^ rcmd
            for b in payload:
                crc ^= b
            if crc == buf[i + 5 + size] and rcmd == cmd:
                return payload if direction == ord(">") else None
            i = buf.find(b"$M", i + 2)
        return None


# ----------------------------------------------------------- link switch

class LinkSwitch:
    """Decides who steers: 'ELRS' (transmitter) or 'IP' (ground station over the network)."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.mode = "ELRS"
        self.reason = "start"
        self._low_since = None
        self._high_since = None

    def update(self, now, lq, allowed, ground_fresh, force):
        """Return (mode, send_neutral). send_neutral is True in the step that leaves IP."""
        c = self.cfg
        if self.mode == "ELRS":
            self._high_since = None
            if not (allowed and ground_fresh):
                self._low_since = None
                return self.mode, False
            if force:
                return self._enter("forced from cockpit"), False
            if lq is not None and lq < c["lq_switch_pct"]:
                if self._low_since is None:
                    self._low_since = now
                if (now - self._low_since) * 1000 >= c["lq_switch_ms"]:
                    return self._enter(f"ELRS LQ {lq}% below {c['lq_switch_pct']}%"), False
            else:
                self._low_since = None
            return self.mode, False

        # mode == "IP"
        if not allowed:
            return self._leave("override not allowed"), True
        if not ground_fresh:
            return self._leave("no command from ground"), True
        if force:
            self._high_since = None
            return self.mode, False
        if lq is not None and lq >= c["lq_return_pct"]:
            if self._high_since is None:
                self._high_since = now
            if (now - self._high_since) * 1000 >= c["lq_return_ms"]:
                return self._leave(f"ELRS LQ back at {lq}%"), True
        else:
            self._high_since = None
        return self.mode, False

    def _enter(self, why):
        self.mode, self.reason = "IP", why
        self._low_since = self._high_since = None
        return self.mode

    def _leave(self, why):
        self.mode, self.reason = "ELRS", why
        self._low_since = self._high_since = None
        return self.mode


def build_rc_frame(rc, rcmap, steer_axis, steer, throttle, cfg):
    """Build the MSP_SET_RAW_RC payload.

    rc      current channels as INAV reports them (order roll, pitch, yaw, throttle, aux...)
    rcmap   INAV channel map: rcmap[internal index] = position in the raw frame
    steer, throttle   -1..+1 from the ground station
    """
    n = max(len(rc), 8)
    raw = [1500] * n
    for i, v in enumerate(rc):
        pos = rcmap[i] if i < len(rcmap) else i
        if pos < n:
            raw[pos] = v if 900 <= v <= 2100 else 1500
    s = max(-1.0, min(1.0, steer)) * (-1 if int(cfg["steer_reverse"]) else 1)
    t = max(-1.0, min(1.0, throttle)) * (-1 if int(cfg["throttle_reverse"]) else 1)
    t *= cfg["throttle_limit_pct"] / 100.0
    si, ti = AXIS_INDEX[steer_axis], AXIS_INDEX["throttle"]
    raw[rcmap[si] if si < len(rcmap) else si] = int(round(1500 + 500 * s))
    raw[rcmap[ti] if ti < len(rcmap) else ti] = int(round(1500 + 500 * t))
    return struct.pack("<%dH" % n, *raw)


def build_rx_frame(ch, cfg, safe=False):
    """MSP_SET_RAW_RC payload for control_mode msp_rx: the transmitter channels 1:1.

    ch    channel values in microseconds as the ground station sent them (channel 1 first)
    safe  True = throttle neutral and steering centred (used while commands are missing)
    """
    raw = [max(1000, min(2000, int(v))) for v in ch[:16]]
    raw += [1500] * (8 - len(raw))
    ti, si = int(cfg["throttle_channel"]) - 1, int(cfg["steer_channel"]) - 1
    neutral = int(cfg["throttle_neutral_us"])
    if safe:
        raw[ti], raw[si] = neutral, 1500
    else:
        raw[ti] = int(round(neutral + (raw[ti] - neutral) * cfg["throttle_limit_pct"] / 100.0))
    return struct.pack("<%dH" % len(raw), *raw)


# ------------------------------------------------------------- FC thread

class Bridge:
    def __init__(self, cfg, warnings, port_factory=None):
        self.cfg = cfg
        self.lock = threading.Lock()
        self.switch = LinkSwitch(cfg)
        self.port_factory = port_factory or self._open_serial
        self.stop = False
        self.ground = {"s": 0.0, "th": 0.0, "force": False, "t": 0.0}
        self.rcin = {"ch": None, "t": 0.0}          # msp_rx: channels from the ground station
        self._stale_since = None
        self.status = {
            "v": fpvcfg.VERSION, "fc_ok": False, "armed": False, "override_sw": False,
            "mode": "ELRS", "reason": "start", "lq": None, "vbat": None, "amps": None,
            "mah": None, "fix": 0, "sats": 0, "lat": None, "lon": None, "alt": None,
            "speed_kmh": None, "course": None, "roll": None, "pitch": None, "yaw": None,
            "rc": [], "control_enable": int(cfg["control_enable"]),
            "control_mode": cfg["control_mode"], "rc_out": None,
            "steer_channel": cfg["steer_channel"], "throttle_channel": cfg["throttle_channel"],
            "throttle_limit_pct": cfg["throttle_limit_pct"], "warnings": warnings,
        }
        self._rcmap = [0, 1, 2, 3]
        self._arm_bit = None
        self._ovr_bit = None
        self._rc = []

    def _open_serial(self):
        import serial  # python3-serial
        return serial.Serial(self.cfg["msp_port"], self.cfg["msp_baud"], timeout=0.01)

    def set_ground(self, steer, throttle, force):
        with self.lock:
            self.ground = {"s": float(steer), "th": float(throttle),
                           "force": bool(force), "t": time.monotonic()}

    def set_rc(self, ch):
        with self.lock:
            self.rcin = {"ch": [int(v) for v in ch], "t": time.monotonic()}

    def _rx_step(self, msp, now):
        """control_mode msp_rx. Returns (mode, reason) and sends at most one RC frame."""
        cfg = self.cfg
        if not int(cfg["control_enable"]):
            return "OFF", "control over IP is switched off in the settings"
        with self.lock:
            r = dict(self.rcin)
        if r["ch"] is None:
            return "WAIT", "waiting for the ground station"
        if (now - r["t"]) * 1000 <= cfg["ground_timeout_ms"]:
            self._stale_since = None
            frame = build_rx_frame(r["ch"], cfg)
            msp.request(MSP_SET_RAW_RC, frame, timeout=0.03)
            self._put(rc_out=list(struct.unpack("<%dH" % (len(frame) // 2), frame))[:8])
            return "IP", "driving over IP"
        if self._stale_since is None:
            self._stale_since = now
        if (now - self._stale_since) * 1000 <= cfg["failsafe_hold_ms"]:
            frame = build_rx_frame(r["ch"], cfg, safe=True)
            msp.request(MSP_SET_RAW_RC, frame, timeout=0.03)
            self._put(rc_out=list(struct.unpack("<%dH" % (len(frame) // 2), frame))[:8])
            return "HOLD", "no command from the ground - neutral"
        self._put(rc_out=None)
        return "FAILSAFE", "no command from the ground - FC failsafe"

    def snapshot(self):
        with self.lock:
            return dict(self.status, boot=_boot_id())

    def _put(self, **kw):
        with self.lock:
            self.status.update(kw)

    # -- telemetry readers -------------------------------------------------
    def _read_static(self, msp):
        m = msp.request(MSP_RX_MAP, timeout=0.3)
        if m and len(m) >= 4:
            self._rcmap = list(m[:4])
        ids = msp.request(MSP_BOXIDS, timeout=0.3)
        if ids is None:
            return False
        ids = list(ids)
        self._arm_bit = ids.index(BOX_ARM) if BOX_ARM in ids else None
        self._ovr_bit = ids.index(BOX_MSP_RC_OVERRIDE) if BOX_MSP_RC_OVERRIDE in ids else None
        return True

    def _poll(self, msp, cmd):
        d = msp.request(cmd)
        if d is None:
            return False
        if cmd == MSP_ANALOG and len(d) >= 7:
            vbat, mah, rssi, amps = struct.unpack_from("<BHHh", d)
            self._put(vbat=vbat / 10.0, mah=mah, amps=amps / 100.0,
                      lq=int(round(rssi * 100 / 1023)))
        elif cmd == MSP_STATUS and len(d) >= 10:
            flags = struct.unpack_from("<I", d, 6)[0]
            bit = lambda b: bool(b is not None and b < 32 and flags >> b & 1)  # noqa: E731
            self._put(armed=bit(self._arm_bit), override_sw=bit(self._ovr_bit))
        elif cmd == MSP_RAW_GPS and len(d) >= 16:
            fix, sats, lat, lon, alt, spd, crs = struct.unpack_from("<BBiihHH", d)
            self._put(fix=fix, sats=sats, lat=lat / 1e7, lon=lon / 1e7, alt=alt,
                      speed_kmh=round(spd * 0.036, 1), course=crs / 10.0)
        elif cmd == MSP_ATTITUDE and len(d) >= 6:
            r, p, y = struct.unpack_from("<hhh", d)
            self._put(roll=r / 10.0, pitch=p / 10.0, yaw=y)
        elif cmd == MSP_RC and len(d) >= 8:
            self._rc = list(struct.unpack("<%dH" % (len(d) // 2), d[:len(d) // 2 * 2]))
            self._put(rc=self._rc[:12])
        return True

    # -- main loop -----------------------------------------------------------
    def run(self):
        order = [MSP_ANALOG, MSP_RC, MSP_STATUS, MSP_RAW_GPS,
                 MSP_ANALOG, MSP_RC, MSP_ATTITUDE, MSP_STATUS]
        while not self.stop:
            try:
                ser = self.port_factory()
            except Exception as e:  # port missing, no permission ...
                self._put(fc_ok=False, reason=f"serial port: {e}")
                time.sleep(2)
                continue
            msp = MspPort(ser)
            try:
                self._session(msp, order)
            except Exception as e:
                self._put(fc_ok=False, reason=f"FC link error: {e}")
            finally:
                try:
                    ser.close()
                except Exception:
                    pass
            time.sleep(1)

    def _session(self, msp, order):
        while not self.stop and not self._read_static(msp):
            self._put(fc_ok=False, reason="no answer from FC")
            time.sleep(1)
        step, misses, neutral_left = 0, 0, 0
        next_tick = time.monotonic()
        while not self.stop:
            now = time.monotonic()
            ok = self._poll(msp, order[step % len(order)])
            step += 1
            misses = 0 if ok else misses + 1
            fc_ok = misses < 12                       # about half a second without answer
            with self.lock:
                g = dict(self.ground)
                st = self.status
                lq, ovr = st["lq"], st["override_sw"]
            if self.cfg["control_mode"] == "msp_rx":
                mode, why = self._rx_step(msp, now)
                self._put(fc_ok=fc_ok, mode=mode, reason=why)
                if misses > 75:
                    raise RuntimeError("FC stopped answering")
                next_tick += TICK_S
                delay = next_tick - time.monotonic()
                if delay > 0:
                    time.sleep(delay)
                else:
                    next_tick = time.monotonic()
                continue
            ground_fresh = (now - g["t"]) * 1000 <= self.cfg["ground_timeout_ms"]
            allowed = bool(int(self.cfg["control_enable"]) and fc_ok and ovr and self._rc)
            mode, send_neutral = self.switch.update(now, lq, allowed, ground_fresh, g["force"])
            if send_neutral:
                neutral_left = NEUTRAL_BURST
            if mode == "IP":
                frame = build_rc_frame(self._rc, self._rcmap, self.cfg["steer_axis"],
                                       g["s"], g["th"], self.cfg)
                msp.request(MSP_SET_RAW_RC, frame, timeout=0.03)
            elif neutral_left and self._rc:
                frame = build_rc_frame(self._rc, self._rcmap, self.cfg["steer_axis"],
                                       0.0, 0.0, self.cfg)
                msp.request(MSP_SET_RAW_RC, frame, timeout=0.03)
                neutral_left -= 1
            self._put(fc_ok=fc_ok, mode=mode, reason=self.switch.reason)
            if misses > 75:                            # 3 s silence: reopen the port
                raise RuntimeError("FC stopped answering")
            next_tick += TICK_S
            delay = next_tick - time.monotonic()
            if delay > 0:
                time.sleep(delay)
            else:
                next_tick = time.monotonic()


def _boot_id():
    import settings
    return settings.BOOT_ID


# ------------------------------------------------------------ web server

async def run_web(bridge, cfg):
    from aiohttp import web, WSMsgType

    here = os.path.dirname(os.path.abspath(__file__))
    clients = set()

    async def index(_req):
        return web.FileResponse(os.path.join(here, "cockpit", "index.html"))

    async def classic(_req):
        return web.FileResponse(os.path.join(here, "cockpit", "classic.html"))

    async def api_status(_req):
        return web.json_response(bridge.snapshot())

    async def ws_handler(req):
        ws = web.WebSocketResponse(heartbeat=10)
        await ws.prepare(req)
        clients.add(ws)
        try:
            async for msg in ws:
                if msg.type != WSMsgType.TEXT:
                    continue
                try:
                    m = json.loads(msg.data)
                except ValueError:
                    continue
                if m.get("t") == "ctl":
                    bridge.set_ground(m.get("s", 0), m.get("th", 0), m.get("force", False))
                elif m.get("t") == "rc":
                    ch = m.get("ch")
                    if isinstance(ch, list) and 4 <= len(ch) <= 16 and \
                            all(isinstance(v, (int, float)) and 800 <= v <= 2200 for v in ch):
                        bridge.set_rc(ch)
                elif m.get("t") == "ping":
                    await ws.send_str(json.dumps({"t": "pong", "ts": m.get("ts")}))
        finally:
            clients.discard(ws)
        return ws

    async def pusher():
        period = 1.0 / cfg["telemetry_hz"]
        while True:
            if clients:
                data = json.dumps({"t": "st", **bridge.snapshot()})
                for ws in list(clients):
                    try:
                        await ws.send_str(data)
                    except Exception:
                        clients.discard(ws)
            await asyncio.sleep(period)

    app = web.Application()
    import settings                       # settings page (V1.5.3)
    settings.add_routes(app, web)
    app.add_routes([web.get("/", index), web.get("/classic", classic), web.get("/api/status", api_status),
                    web.get("/ws", ws_handler)])
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "0.0.0.0", cfg["web_port"]).start()
    print(f"[fpv-bridge] cockpit on port {cfg['web_port']}", flush=True)
    await pusher()


def main():
    cfg, warnings = fpvcfg.load()
    print(f"[fpv-bridge] Mojave FPV LTE {fpvcfg.VERSION}", flush=True)
    for w in warnings:
        print(f"[fpv-bridge] WARNING: {w}", flush=True)
    bridge = Bridge(cfg, warnings)
    threading.Thread(target=bridge.run, daemon=True).start()
    asyncio.run(run_web(bridge, cfg))


if __name__ == "__main__":
    main()
