#!/usr/bin/env python3
"""Mojave FPV LTE V1.9 - recording of a drive on the Pi itself.

The pictures and the sound are written to the SD card exactly as the cameras deliver them (copied, not
encoded again): no load on the notebook, full quality, nothing is lost when the mobile link is bad.
All values (GPS, speed, battery ...) go into a time line beside them. One folder per drive:
  /var/lib/fpv/rec/<id>/cam.mp4  cam2.mp4  mic.mp4  tl.jsonl  meta.json
The cockpit plays a drive straight from the Pi or fetches it as one file (.fpvrec) for the player."""
import asyncio, json, os, re, shutil, signal, subprocess, time

REC_DIR = os.environ.get("FPV_REC", "/var/lib/fpv/rec")
MIME = {"cam": "video/mp4", "cam2": "video/mp4", "mic": "audio/mp4"}
KEYS = ("speed_kmh", "course", "yaw", "lat", "lon", "alt", "fix", "sats", "vbat", "cells", "lq", "armed", "fc_ok", "mode",
        "trip_m", "home_dist_m", "home_bearing", "home_set", "steer_channel", "throttle_channel", "rc_out")


class Recorder:
    def __init__(self, cfg, paths_fn):
        self.cfg, self.paths_fn = cfg, paths_fn
        self.cur = None                      # running drive: {id, dir, t0, procs:{path:proc}, segs:{path:{...}}, tl, drv}
        self.client = {}                     # last numbers reported by the cockpit (answer time, Mbit/s)
        self.disarmed_at = None
        self.by_arm = False
        os.makedirs(REC_DIR, exist_ok=True)
        for d in self._ids():                # a drive that was cut off (power, restart): close it
            if not os.path.isfile(os.path.join(REC_DIR, d, "meta.json")):
                self._finish_dir(os.path.join(REC_DIR, d), d)

    # ---- files
    def _ids(self):
        try:
            return sorted(d for d in os.listdir(REC_DIR) if re.fullmatch(r"\d{8}_\d{6}", d))
        except OSError:
            return []

    def _free_mb(self):
        return shutil.disk_usage(REC_DIR).free // (1024 * 1024)

    def _make_room(self):
        keep = int(self.cfg["record_keep_free_mb"])
        for d in self._ids():
            if self._free_mb() >= keep:
                break
            if self.cur and d == self.cur["id"]:
                continue
            shutil.rmtree(os.path.join(REC_DIR, d), ignore_errors=True)
            print(f"[rec] SD card nearly full - oldest drive {d} deleted", flush=True)

    def _finish_dir(self, path, rid, segs=None, t0=None, summary=None):
        dur, start = 0, None
        try:
            with open(os.path.join(path, "tl.jsonl"), "rb") as f:
                lines = f.read().splitlines()
            if lines:
                dur = json.loads(lines[-1]).get("t", 0)
        except (OSError, ValueError):
            pass
        if segs is None:                     # after a cut-off: take the files as they are
            segs = {p: {"t0": 0, "t1": dur} for p in MIME if os.path.isfile(os.path.join(path, p + ".mp4"))}
        out = []
        for p, g in segs.items():
            f = os.path.join(path, p + ".mp4")
            if os.path.isfile(f) and os.path.getsize(f) > 2000 and g.get("t0") is not None:
                out.append({"path": p, "file": p + ".mp4", "t0": round(g["t0"]), "t1": round(g.get("t1") or dur), "mime": MIME[p],
                            "size": os.path.getsize(f)})
        try:
            start = int(time.mktime(time.strptime(rid, "%Y%m%d_%H%M%S")) * 1000)
        except ValueError:
            start = int(time.time() * 1000)
        meta = {"id": rid, "start": start, "dur": round(dur), "segs": out, "v": "V1.9", "sum": summary}
        with open(os.path.join(path, "meta.json"), "w") as f:
            json.dump(meta, f)
        return meta

    def listing(self):
        res = []
        for d in reversed(self._ids()):
            if self.cur and d == self.cur["id"]:
                continue
            try:
                with open(os.path.join(REC_DIR, d, "meta.json")) as f:
                    m = json.load(f)
                m["size"] = sum(g.get("size", 0) for g in m["segs"])
                res.append(m)
            except (OSError, ValueError):
                pass
        return res

    def state(self):
        c = self.cur
        return {"on": bool(c), "id": c["id"] if c else None, "t": round((time.monotonic() - c["t0"]) * 1000) if c else 0}

    # ---- start / stop
    def start(self, by_arm=False):
        if self.cur:
            return True
        self._make_room()
        if self._free_mb() < 300:
            print("[rec] SD card full - not recording", flush=True)
            return False
        rid = time.strftime("%Y%m%d_%H%M%S")
        path = os.path.join(REC_DIR, rid)
        os.makedirs(path, exist_ok=True)
        want = [p for p in self.paths_fn() if p in MIME and (p != "cam2" or int(self.cfg["record_cam2"]))]
        procs, segs = {}, {}
        for p in want:
            cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-fflags", "nobuffer", "-probesize", "32768", "-analyzeduration", "0",
                   "-rtsp_transport", "tcp", "-i", f"rtsp://127.0.0.1:8554/{p}",
                   "-c", "copy", "-f", "mp4", "-movflags", "frag_keyframe+empty_moov+default_base_moof", "-frag_duration", "1000000",
                   os.path.join(path, p + ".mp4")]
            try:
                procs[p] = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                segs[p] = {"t0": None, "t1": None}
            except OSError as e:
                print(f"[rec] could not start the recorder for {p}: {e}", flush=True)
        self.cur = {"id": rid, "dir": path, "t0": time.monotonic(), "procs": procs, "segs": segs, "drv": 0.0, "last": time.monotonic(),
                    "tl": open(os.path.join(path, "tl.jsonl"), "a", buffering=1), "space": time.monotonic()}
        self.by_arm = by_arm
        print(f"[rec] drive {rid} started ({', '.join(procs) or 'values only'})", flush=True)
        return True

    def stop(self, summary=None):
        c, self.cur = self.cur, None
        if not c:
            return None
        now = (time.monotonic() - c["t0"]) * 1000
        for p, pr in c["procs"].items():
            if pr.poll() is None:
                pr.send_signal(signal.SIGINT)
            c["segs"][p]["t1"] = now
        for pr in c["procs"].values():
            try:
                pr.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pr.kill()
        c["tl"].close()
        for p, g in c["segs"].items():       # exact start of each file: its end is known, its length is measured
            try:
                out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0",
                                      os.path.join(c["dir"], p + ".mp4")], capture_output=True, text=True, timeout=15).stdout.strip()
                g["t0"] = max(0.0, g["t1"] - float(out) * 1000)
            except (OSError, ValueError, subprocess.TimeoutExpired):
                pass
        meta = self._finish_dir(c["dir"], c["id"], c["segs"], summary=summary)
        print(f"[rec] drive {c['id']} saved, {meta['dur'] / 1000:.0f} s", flush=True)
        self.disarmed_at = None
        return meta

    def set_summary(self, rid, summary):
        f = os.path.join(REC_DIR, rid, "meta.json")
        try:
            with open(f) as fh:
                m = json.load(fh)
            m["sum"] = summary
            with open(f, "w") as fh:
                json.dump(m, fh)
            return True
        except (OSError, ValueError):
            return False

    def delete(self, rid):
        if re.fullmatch(r"\d{8}_\d{6}", rid or "") and not (self.cur and self.cur["id"] == rid):
            shutil.rmtree(os.path.join(REC_DIR, rid), ignore_errors=True)
            return True
        return False

    # ---- called 5 times a second with the current values
    def step(self, st):
        now = time.monotonic()
        armed = bool(st.get("fc_ok") and st.get("armed"))
        if int(self.cfg["record_armed"]):
            if armed:
                self.disarmed_at = None
                if not self.cur:
                    self.start(by_arm=True)
            elif self.cur and self.by_arm:
                if self.disarmed_at is None:
                    self.disarmed_at = now
                elif now - self.disarmed_at >= float(self.cfg["record_after_s"]):
                    self.stop()
        c = self.cur
        if not c:
            return
        t = (now - c["t0"]) * 1000
        for p, g in c["segs"].items():       # a recorder has written its first data: from here its file counts
            if g["t0"] is None:
                try:
                    if os.path.getsize(os.path.join(c["dir"], p + ".mp4")) > 0:
                        g["t0"] = max(0.0, t - 300)
                except OSError:
                    pass
        if armed:
            c["drv"] += (now - c["last"]) * 1000
        c["last"] = now
        row = {"t": round(t), "s": {k: st[k] for k in KEYS if st.get(k) is not None}, "drv": round(c["drv"])}
        if now - self.client.get("at", 0) < 5:
            row["ping"], row["mb"] = self.client.get("ping"), self.client.get("mb")
        c["tl"].write(json.dumps(row, separators=(",", ":")) + "\n")
        if now - c["space"] > 10:
            c["space"] = now
            if self._free_mb() < 200:
                print("[rec] SD card full - recording stopped", flush=True)
                self.stop()


def add_routes(app, web, rec):
    def guard(req):
        return req.headers.get("X-FPV") == "1"

    async def get_rec(_req):
        return web.json_response({**rec.state(), "free_mb": rec._free_mb(), "list": rec.listing()})

    async def post_rec(req):
        if not guard(req):
            return web.json_response({"ok": False, "error": "missing header"}, status=403)
        try:
            data = await req.json()
        except ValueError:
            data = {}
        act = data.get("do")
        if act == "start":
            return web.json_response({"ok": rec.start(), **rec.state()})
        if act == "stop":
            meta = await asyncio.get_running_loop().run_in_executor(None, rec.stop, data.get("sum"))
            return web.json_response({"ok": True, "saved": meta and meta["id"], **rec.state()})
        if act == "sum":
            return web.json_response({"ok": rec.set_summary(str(data.get("id")), data.get("sum"))})
        if act == "delete":
            return web.json_response({"ok": rec.delete(str(data.get("id")))})
        return web.json_response({"ok": False, "error": "unknown"}, status=400)

    async def get_file(req):
        rid, name = req.match_info["id"], req.match_info["name"]
        if not re.fullmatch(r"\d{8}_\d{6}", rid) or not re.fullmatch(r"[a-z0-9]+\.(mp4|jsonl|json)", name):
            raise web.HTTPNotFound()
        f = os.path.join(REC_DIR, rid, name)
        if not os.path.isfile(f):
            raise web.HTTPNotFound()
        return web.FileResponse(f)           # answers range requests, so the browser can jump in the video

    async def get_pack(req):
        """One drive as a single file for the player: "FPVREC01" + all pieces + values + list + length of the list."""
        rid = req.match_info["id"]
        d = os.path.join(REC_DIR, rid)
        try:
            with open(os.path.join(d, "meta.json")) as f:
                meta = json.load(f)
            with open(os.path.join(d, "tl.jsonl")) as f:
                tl = ("[" + ",".join(line.strip() for line in f if line.strip()) + "]").encode()
        except (OSError, ValueError):
            raise web.HTTPNotFound()
        off, segs = 8, []
        for g in meta["segs"]:
            size = os.path.getsize(os.path.join(d, g["file"]))
            segs.append({"slot": {"cam": "main", "cam2": "pip", "mic": "snd"}[g["path"]], "t0": g["t0"], "t1": g["t1"], "mime": g["mime"],
                         "off": off, "len": size, "file": g["file"]})
            off += size
        idx = json.dumps({"start": meta["start"], "dur": meta["dur"], "v": meta.get("v"), "sum": meta.get("sum"), "pi": 1,
                          "segs": [{k: v for k, v in s.items() if k != "file"} for s in segs], "tl": {"off": off, "len": len(tl)}}).encode()
        total = off + len(tl) + len(idx) + 16
        resp = web.StreamResponse(headers={"Content-Type": "application/octet-stream", "Content-Length": str(total),
                                           "Content-Disposition": f'attachment; filename="FPV_{rid}.fpvrec"'})
        await resp.prepare(req)
        await resp.write(b"FPVREC01")
        for s in segs:
            with open(os.path.join(d, s["file"]), "rb") as f:
                left = s["len"]
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        chunk = b"\0" * left
                    await resp.write(chunk)
                    left -= len(chunk)
        await resp.write(tl + idx + str(len(idx)).zfill(16).encode())
        return resp

    app.add_routes([web.get("/api/rec", get_rec), web.post("/api/rec", post_rec),
                    web.get("/rec/{id}.fpvrec", get_pack), web.get("/rec/{id}/{name}", get_file)])
