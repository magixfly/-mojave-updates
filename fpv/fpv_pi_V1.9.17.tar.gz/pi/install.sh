#!/bin/bash
# Mojave FPV LTE V1.9.17 - installer for Raspberry Pi 4 (Raspberry Pi OS Lite 64-bit, Bookworm or newer)
# Run on the Pi:   sudo bash install.sh
set -e
VERSION="V1.9.17"
SRC="$(cd "$(dirname "$0")" && pwd)"
BOOT=/boot/firmware
[ -d "$BOOT" ] || BOOT=/boot
STEPS=8
step=0

bar() {  # progress bar with percent
  step=$((step + 1))
  local pct=$((step * 100 / STEPS)) fill=$((step * 30 / STEPS))
  printf '\n[%-30s] %3d%%  %s\n' "$(printf '#%.0s' $(seq 1 $fill))" "$pct" "$1"
}

if [ "$(id -u)" != "0" ]; then echo "Please run with sudo: sudo bash install.sh"; exit 1; fi
echo "Mojave FPV LTE $VERSION - installing"

bar "Installing packages (takes a few minutes)"
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  python3-serial python3-aiohttp ffmpeg alsa-utils v4l-utils curl jq wireguard-tools \
  usb-modeswitch usbmuxd network-manager \
  gstreamer1.0-tools gstreamer1.0-rtsp gstreamer1.0-alsa \
  gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad >/dev/null

bar "Downloading the video server MediaMTX"
mkdir -p /opt/fpv /etc/fpv
if [ ! -x /opt/fpv/mediamtx ]; then
  URL=$(curl -fsSL https://api.github.com/repos/bluenviron/mediamtx/releases/latest \
        | jq -r '.assets[].browser_download_url' | grep -E 'linux_arm64(v8)?\.tar\.gz$' | head -n 1)
  if [ -z "$URL" ]; then echo "ERROR: MediaMTX download address not found (no internet?)"; exit 1; fi
  curl -fL --progress-bar "$URL" -o /tmp/mediamtx.tar.gz
  tar -xzf /tmp/mediamtx.tar.gz -C /opt/fpv mediamtx
  rm -f /tmp/mediamtx.tar.gz
fi

bar "Copying the programs to /opt/fpv"
cp "$SRC/bridge.py" "$SRC/apply_config.py" "$SRC/fpvcfg.py" "$SRC/settings.py" "$SRC/remote.py" "$SRC/usbcam.sh" /opt/fpv/
rm -rf /opt/fpv/cockpit && cp -r "$SRC/cockpit" /opt/fpv/
chmod +x /opt/fpv/bridge.py /opt/fpv/apply_config.py

bar "Settings file on the SD card"
if [ -f "$BOOT/fpv-config.txt" ]; then
  echo "  $BOOT/fpv-config.txt exists - kept as it is"
else
  cp "$SRC/fpv-config.txt" "$BOOT/fpv-config.txt"
fi

if [ ! -f "$BOOT/fpv-remote.txt" ]; then cp "$SRC/fpv-remote.txt" "$BOOT/fpv-remote.txt"; fi

bar "Camera IMX462 and serial port in $BOOT/config.txt"
CFG="$BOOT/config.txt"
cp -n "$CFG" "$CFG.before-fpv"
sed -i 's/^camera_auto_detect=1/camera_auto_detect=0/' "$CFG"
grep -q '^camera_auto_detect=' "$CFG" || echo 'camera_auto_detect=0' >> "$CFG"
if ! grep -q '^# --- Mojave FPV LTE' "$CFG"; then
  cat >> "$CFG" <<'CFGEOF'

# --- Mojave FPV LTE ---
[all]
# InnoMaker CAM-MIPI462RAW (IMX462) uses the built-in imx290 driver, 74.25 MHz clock
dtoverlay=imx290,clock-frequency=74250000
# Full UART on GPIO 14/15 (pins 8/10) for the flight controller, Bluetooth off
enable_uart=1
dtoverlay=disable-bt
CFGEOF
fi

if ! grep -qE "^gpu_mem=" "$CFG"; then
  printf '\n# Mojave FPV LTE: memory for the video chip (USB camera next to the main camera)\ngpu_mem=256\n' >> "$CFG"
fi

bar "Serial port: free it for the flight controller"
raspi-config nonint do_serial_hw 0 || true      # serial hardware on
raspi-config nonint do_serial_cons 1 || true    # no login console on it
systemctl disable --now hciuart 2>/dev/null || true

bar "Services (start automatically at power-on)"
cp "$SRC"/systemd/*.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable fpv-setup.service fpv-mediamtx.service fpv-bridge.service fpv-remote.service >/dev/null

bar "Done"
echo
echo "Installed: Mojave FPV LTE $VERSION"
echo "Next: sudo reboot"
echo "Then open in a browser:  http://$(hostname).local:8080"
echo "Settings page:            http://$(hostname).local:8080/settings"
