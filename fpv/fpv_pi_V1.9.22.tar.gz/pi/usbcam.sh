#!/bin/bash
# Mojave FPV LTE V1.9.22 - one USB camera -> H.264 -> video server. Started by MediaMTX while somebody watches.
#   usbcam.sh DEVICE WIDTH HEIGHT FPS KBIT PATH [auto|hw|sw|ffmpeg]
# hw     = JPEG decoding and H.264 encoding both in the Pi's video chip. Works up to 1280x720 (needs gpu_mem=256).
# sw     = JPEG decoding in software (GStreamer), encoding in the chip. For 1920x1080.
# ffmpeg = the old way (most load, loses pictures at 1080p)
# auto   = hw up to 720p, sw above; falls back to ffmpeg if the chosen way stops or stalls
# Measured on the Pi 4 (25.11.2026), main camera running: 720p hw 25 % CPU, 1080p sw 67 %, 1080p ffmpeg 95 % with lost pictures.
D=$1; W=$2; H=$3; F=$4; K=$5; P=$6; MODE=${7:-auto}
URL="rtsp://localhost:8554/$P"
BAD="/run/fpv-usbcam-$P.ffmpeg"                    # written when hw/sw failed; cleared at reboot
for c in power_line_frequency=1 exposure_dynamic_framerate=0 exposure_auto_priority=0; do
  v4l2-ctl -d "$D" -c "$c" >/dev/null 2>&1          # 50 Hz mains, keep the frame rate in the dark
done
SRC=(v4l2src "device=$D" do-timestamp=true ! "image/jpeg,width=$W,height=$H,framerate=$F/1")
ENC=(v4l2h264enc "extra-controls=controls,video_bitrate=$((K * 1000)),h264_i_frame_period=$F,repeat_sequence_header=1"
     ! "video/x-h264,level=(string)4.2" ! h264parse config-interval=-1 ! rtspclientsink "location=$URL" protocols=tcp latency=0)
cmd_hw() { gst-launch-1.0 -q "${SRC[@]}" ! v4l2jpegdec ! "video/x-raw,format=I420" ! "${ENC[@]}"; }
cmd_sw() { gst-launch-1.0 -q "${SRC[@]}" ! jpegdec ! videoconvert ! "video/x-raw,format=I420" ! "${ENC[@]}"; }
cmd_ffmpeg() { ffmpeg -hide_banner -loglevel warning -fflags nobuffer -flags low_delay -probesize 32 -analyzeduration 0 \
  -f v4l2 -input_format mjpeg -video_size "${W}x${H}" -framerate "$F" -i "$D" \
  -pix_fmt yuv420p -c:v h264_v4l2m2m -b:v "${K}k" -g "$F" -bf 0 -f rtsp -rtsp_transport tcp "$URL"; }
ticks() { awk '{print $14 + $15}' "/proc/$1/stat" 2>/dev/null || echo 0; }
STOP=0
run() {                                              # returns 0 = stopped by the video server, 1 = failed
  local mode=$1 t0 pid child
  echo "[usbcam] $P: $D ${W}x${H}@$F ${K}k, mode $mode"
  t0=$(date +%s); "cmd_$mode" & pid=$!
  trap 'STOP=1; pkill -INT -P '"$pid"' 2>/dev/null; kill -INT '"$pid"' 2>/dev/null' INT TERM
  if [ "$mode" != "ffmpeg" ]; then                   # watchdog: a pipeline that does no work after 12 s hangs
    ( sleep 12; child=$(pgrep -P "$pid" | head -1); [ -n "$child" ] || exit 0
      [ -e "$D" ] || exit 0                           # camera unplugged: not the pipeline's fault
      [ "$(ticks "$child")" -lt 60 ] && { echo "[usbcam] $P: mode $mode does no work - stopping it"; touch "$BAD"; pkill -KILL -P "$pid"; } ) &
  fi
  wait "$pid"; trap - INT TERM
  [ "$STOP" = 1 ] && return 0
  [ $(( $(date +%s) - t0 )) -ge 20 ] && [ ! -e "$BAD" ] && return 0
  return 1
}
if [ "$MODE" = "auto" ]; then
  if [ -e "$BAD" ]; then MODE=ffmpeg; elif [ "$H" -le 720 ]; then MODE=hw; else MODE=sw; fi
fi
[ -e "$D" ] || { echo "[usbcam] $P: camera $D is not plugged in"; sleep 5; exit 1; }
# the small and the big version of one camera share the device: wait until the other one has let go of it
for i in $(seq 1 56); do pgrep -f "v4l2src device=$D |-i $D " >/dev/null || break; sleep 0.25; done
pgrep -f "v4l2src device=$D |-i $D " >/dev/null && { echo "[usbcam] $P: $D is still in use"; exit 1; }
run "$MODE" && exit 0
[ -e "$D" ] || { echo "[usbcam] $P: camera was unplugged"; exit 1; }      # do not blame the pipeline for that
if [ "$MODE" != "ffmpeg" ]; then touch "$BAD"; echo "[usbcam] $P: mode $MODE failed - using ffmpeg until the next restart"; run ffmpeg; fi
exit 1
