#!/usr/bin/env python3
"""Passes the settings page of the LTE stick through the Pi.

The stick is only reachable from the Pi (USB network). This small forwarder
listens on the Pi and hands every connection on to the stick, so the page can
be opened from the notebook as http://<pi>:8081/

Optional lines in /boot/firmware/fpv-config.txt:
  stick_page_port = 8081          port on the Pi (0 = switched off)
  stick_page_addr = auto          address of the stick; auto = the gateway the stick
                                  hands out (it is not always the same, e.g. 192.168.100.1 or .33)
"""
import asyncio, os, re, subprocess, sys, time

CFG = "/boot/firmware/fpv-config.txt"
port, addr = 8081, "auto"
try:
    for line in open(CFG, encoding="utf-8", errors="replace"):
        m = re.match(r"\s*(stick_page_port|stick_page_addr)\s*=\s*([^#\s]+)", line)
        if m and m.group(1) == "stick_page_port":
            port = int(m.group(2))
        elif m:
            addr = m.group(2)
except (OSError, ValueError):
    pass
if len(sys.argv) > 2:                       # test: stickpage.py <port> <addr[:port]>
    port, addr = int(sys.argv[1]), sys.argv[2]
_found = {"at": 0.0, "host": "192.168.100.1"}


def stick_gateway():
    """Gateway of the default route that runs over a USB network card (the stick). Cached for 10 s."""
    if time.monotonic() - _found["at"] < 10:
        return _found["host"]
    _found["at"] = time.monotonic()
    try:
        out = subprocess.run(["ip", "-4", "route", "show", "default"], capture_output=True, text=True, timeout=3).stdout
    except (OSError, subprocess.SubprocessError):
        return _found["host"]
    for line in out.splitlines():
        p = line.split()
        if "via" in p and "dev" in p:
            dev = p[p.index("dev") + 1]
            try:
                usb = "/usb" in os.path.realpath(f"/sys/class/net/{dev}/device")
            except OSError:
                usb = False
            if usb or dev.startswith(("usb", "wwan")):
                _found["host"] = p[p.index("via") + 1]
                break
    return _found["host"]


def target():
    if addr == "auto":
        return stick_gateway(), 80
    host, _, tport = addr.partition(":")
    return host, int(tport or 80)


async def pipe(r, w):
    try:
        while data := await r.read(65536):
            w.write(data)
            await w.drain()
    except (ConnectionError, OSError):
        pass
    finally:
        try:
            w.close()
        except OSError:
            pass


async def handle(cr, cw):
    try:
        host, tport = target()
        sr, sw = await asyncio.wait_for(asyncio.open_connection(host, tport), 6)
    except (OSError, asyncio.TimeoutError):
        cw.write(b"HTTP/1.1 502 Bad Gateway\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\n"
                 b"The LTE stick does not answer. Is it plugged into the Pi?\n")
        await cw.drain()
        cw.close()
        return
    await asyncio.gather(pipe(cr, sw), pipe(sr, cw))


async def main():
    if port <= 0:
        print("[stickpage] switched off (stick_page_port = 0)", flush=True)
        await asyncio.Event().wait()
    srv = await asyncio.start_server(handle, "0.0.0.0", port)
    print(f"[stickpage] port {port} -> {addr} (now {target()[0]})", flush=True)
    async with srv:
        await srv.serve_forever()

asyncio.run(main())
