"""Mojave FPV LTE V1.9.28 - settings web page (part of the bridge web server).

Everything the page changes ends up in /boot/firmware/fpv-config.txt, so the
text file stays the single place where the settings live.

Routes (all under the cockpit port, default 8080):
  GET  /settings                 the page
  GET  /api/config               all settings with description and limits
  POST /api/config               save changed settings into fpv-config.txt
  POST /api/apply                write video server file, restart video + bridge
  GET  /api/system               versions, addresses, services, temperature
  GET  /api/wifi   POST /api/wifi/add   POST /api/wifi/delete
  GET  /api/vpn    POST /api/vpn/upload POST /api/vpn/enable  POST /api/vpn/remove
  GET  /api/log?unit=...         last lines of a service log
  GET  /api/remote  POST /api/remote/token  POST /api/remote/enable  GET /api/remote/log?name=
  POST /api/power                reboot or shut down
"""
import asyncio
import json
import os
import re
import shutil
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fpvcfg  # noqa: E402
import apply_config  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
DRY = bool(os.environ.get("FPV_DRY"))          # test mode: no system commands
BOOT_ID = str(int(time.time() * 1000))         # changes when the bridge restarts
UNITS = {"video": "fpv-mediamtx", "bridge": "fpv-bridge", "setup": "fpv-setup",
         "vpn": "wg-quick@wg0", "remote": "fpv-remote", "tailscale": "tailscaled"}
REMOTE_CONF = os.environ.get("FPV_REMOTE_CONF", "/boot/firmware/fpv-remote.txt")
REMOTE_TOKEN = os.environ.get("FPV_REMOTE_TOKEN", "/etc/fpv/github-token")
REMOTE_STATE = os.environ.get("FPV_REMOTE_STATE", "/var/lib/fpv-remote")
REMOTE_STATUS = os.environ.get("FPV_REMOTE_STATUS", "/run/fpv-remote.json")
dry_log = []                                   # commands "run" in test mode


async def run(cmd, timeout=25, stdin=None):
    """Run a system command. Returns (exit code, output text)."""
    if DRY:
        dry_log.append(cmd)
        return 0, ""
    try:
        p = await asyncio.create_subprocess_exec(
            *cmd, stdin=asyncio.subprocess.PIPE if stdin else None,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        out, _ = await asyncio.wait_for(p.communicate(stdin.encode() if stdin else None), timeout)
        return p.returncode, out.decode("utf-8", "replace").strip()
    except FileNotFoundError:
        return 127, f"{cmd[0]}: not installed"
    except asyncio.TimeoutError:
        return 124, f"{cmd[0]}: no answer after {timeout} s"


# ------------------------------------------------------------ fpv-config.txt

def config_path():
    return os.environ.get("FPV_CONFIG") or fpvcfg.find_config() or fpvcfg.CONFIG_PATHS[0]


def write_config(changes):
    """Put new values into fpv-config.txt. Comments and order stay as they are."""
    path = config_path()
    lines = []
    if os.path.isfile(path):
        with open(path, encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
    left = dict(changes)
    for i, line in enumerate(lines):
        m = re.match(r"^(\s*)([A-Za-z0-9_]+)(\s*=\s*)([^#]*?)(\s*)(#.*)?$", line)
        if not m or m.group(2) not in left:
            continue
        val = str(left.pop(m.group(2)))
        old_len = len(m.group(4)) + len(m.group(5))
        pad = " " * max(1, old_len - len(val)) if m.group(6) else ""
        lines[i] = f"{m.group(1)}{m.group(2)}{m.group(3)}{val}{pad}{m.group(6) or ''}".rstrip()
    if left:
        lines += ["", "# ---- Added by the settings page ----"]
        lines += [f"{k} = {v}" for k, v in left.items()]
    tmp = path + ".new"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")
        f.flush()
        os.fsync(f.fileno())
    if os.path.isfile(path):
        shutil.copyfile(path, path + ".bak")      # one step back, readable on any PC
    os.replace(tmp, path)


def config_payload():
    cfg, warnings = fpvcfg.load(config_path() if os.path.isfile(config_path()) else None)
    fields = []
    for key, group, label, kind, hint in fpvcfg.FIELDS:
        lo, hi = fpvcfg.LIMITS.get(key, (None, None))
        fields.append({"key": key, "group": group, "label": label, "kind": kind, "hint": hint,
                       "value": cfg[key], "default": fpvcfg.DEFAULTS[key], "min": lo, "max": hi})
    return {"version": fpvcfg.VERSION, "boot": BOOT_ID, "file": config_path(),
            "warnings": warnings, "fields": fields}


# ------------------------------------------------------------ helpers

def clean_ssid(s):
    s = str(s or "").strip()
    return s if 1 <= len(s.encode()) <= 32 and "\n" not in s else None


async def wifi_state():
    _, saved = await run(["nmcli", "-t", "-f", "NAME,TYPE,AUTOCONNECT-PRIORITY", "connection", "show"])
    _, active = await run(["nmcli", "-t", "-f", "ACTIVE,SSID,SIGNAL,FREQ", "device", "wifi", "list",
                           "--rescan", "no"])
    nets, current, seen = [], None, []
    for line in saved.splitlines():
        parts = line.rsplit(":", 2)
        if len(parts) == 3 and parts[1] == "802-11-wireless":
            nets.append({"name": parts[0].replace("\\:", ":"), "priority": parts[2]})
    for line in active.splitlines():
        parts = line.replace("\\:", "\x00").split(":")
        if len(parts) < 4 or not parts[1]:
            continue
        ssid = parts[1].replace("\x00", ":")
        ghz = "5 GHz" if parts[3].startswith("5") else "2.4 GHz"
        if parts[0] == "yes":
            current = {"ssid": ssid, "signal": parts[2], "band": ghz}
        if ssid not in [s["ssid"] for s in seen]:
            seen.append({"ssid": ssid, "signal": parts[2], "band": ghz})
    return {"saved": nets, "current": current, "visible": seen[:15]}


async def vpn_state():
    conf = os.path.join(apply_config.WG_DIR, "wg0.conf")
    present = os.path.isfile(conf)
    code, shake = await run(["wg", "show", "wg0", "latest-handshakes"])
    up = code == 0 and not DRY
    age = None
    if up and shake:
        try:
            ts = int(shake.split()[-1])
            age = int(time.time()) - ts if ts else None
        except ValueError:
            pass
    _, enabled = await run(["systemctl", "is-enabled", "wg-quick@wg0"])
    endpoint = nets = None
    if present:
        try:
            with open(conf, encoding="utf-8", errors="replace") as f:
                for line in f:
                    low = line.strip().lower()
                    if low.startswith("endpoint"):
                        endpoint = line.split("=", 1)[1].strip()
                    if low.startswith("allowedips"):
                        nets = line.split("=", 1)[1].strip()
        except OSError:
            pass
    return {"present": present, "up": up, "handshake_age_s": age,
            "autostart": enabled.strip() == "enabled", "endpoint": endpoint, "networks": nets}


async def system_state():
    info = {"version": fpvcfg.VERSION, "boot": BOOT_ID, "hostname": os.uname().nodename}
    _, ips = await run(["ip", "-4", "-o", "addr", "show", "scope", "global"])
    info["addresses"] = [{"if": p[1], "ip": p[3].split("/")[0]}
                         for p in (l.split() for l in ips.splitlines()) if len(p) > 3]
    services = {}
    for name, unit in UNITS.items():
        _, st = await run(["systemctl", "is-active", unit])
        services[name] = st.strip() or "unknown"
    info["services"] = services
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            info["temp_c"] = round(int(f.read()) / 1000, 1)
    except (OSError, ValueError):
        info["temp_c"] = None
    code, thr = await run(["vcgencmd", "get_throttled"])
    flags = None
    if code == 0 and "=" in thr:
        try:
            flags = int(thr.split("=")[1], 16)
        except ValueError:
            pass
    info["undervoltage_now"] = bool(flags & 0x1) if flags is not None else None
    info["undervoltage_seen"] = bool(flags & 0x10000) if flags is not None else None
    # Never open the camera here: the video server owns it. Ask the kernel driver instead.
    import glob
    bound = glob.glob("/sys/bus/i2c/drivers/imx*/*-00*")
    info["camera_found"] = bool(bound)
    info["camera_name"] = bound[0].split("/")[-2] if bound else None
    try:
        st = os.statvfs("/")
        info["disk_free_mb"] = st.f_bavail * st.f_frsize // 1048576
    except OSError:
        pass
    return info


def remote_enabled():
    try:
        with open(REMOTE_CONF, encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.split("#", 1)[0].strip()
                if line.startswith("remote_enable") and "=" in line:
                    return line.split("=", 1)[1].strip() == "1"
    except OSError:
        pass
    return True


def set_remote_enabled(on):
    lines, found = [], False
    try:
        with open(REMOTE_CONF, encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
    except OSError:
        lines = ["# Mojave FPV LTE - remote maintenance over GitHub"]
    for i, line in enumerate(lines):
        if re.match(r"^\s*remote_enable\s*=", line):
            lines[i], found = f"remote_enable = {1 if on else 0}", True
    if not found:
        lines.append(f"remote_enable = {1 if on else 0}")
    with open(REMOTE_CONF, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")


def remote_state():
    st = {}
    try:
        with open(REMOTE_STATUS, encoding="utf-8") as f:
            st = json.load(f)
    except (OSError, ValueError):
        pass
    results = []
    try:
        d = os.path.join(REMOTE_STATE, "out")
        results = sorted((n[:-4] for n in os.listdir(d) if n.endswith(".log")), reverse=True)[:12]
    except OSError:
        pass
    age = int(time.time() - st["t"]) if st.get("t") else None
    return {"enabled": remote_enabled(), "token": os.path.isfile(REMOTE_TOKEN),
            "last_poll_age_s": age, "ok": st.get("ok"), "error": st.get("error"),
            "running": st.get("running"), "last_cmd": st.get("last_cmd"), "results": results}


async def tailscale_state():
    code, ip = await run(["tailscale", "ip", "-4"], timeout=6)
    if code == 127:
        return {"installed": False}
    _, st = await run(["tailscale", "status", "--json"], timeout=6)
    name = state = None
    try:
        j = json.loads(st)
        state = j.get("BackendState")
        name = (j.get("Self") or {}).get("DNSName", "").rstrip(".") or None
    except ValueError:
        pass
    return {"installed": True, "ip": ip.splitlines()[0] if code == 0 and ip else None,
            "state": state, "name": name}


def video_paths():
    """Names of the video paths the video server offers right now (cam, live, cam2 ...)."""
    try:
        with open(os.path.join(apply_config.OUT_DIR, "mediamtx.yml"), encoding="utf-8") as f:
            return re.findall(r"^  ([a-z0-9]+):\s*$", f.read(), re.M)
    except OSError:
        return ["cam"]


# ------------------------------------------------------------ routes

def add_routes(app, web):
    def ok(**kw):
        return web.json_response({"ok": True, **kw})

    def fail(msg, **kw):
        return web.json_response({"ok": False, "error": msg, **kw})

    async def body(req):
        """JSON body; refuses requests that do not come from our own page."""
        if req.headers.get("X-FPV") != "1":
            raise web.HTTPForbidden(text="missing X-FPV header")
        try:
            data = await req.json()
        except ValueError:
            raise web.HTTPBadRequest(text="JSON expected")
        return data if isinstance(data, dict) else {}

    async def page(_req):
        return web.FileResponse(os.path.join(HERE, "cockpit", "settings.html"))

    async def get_config(_req):
        return web.json_response(config_payload())

    async def post_config(req):
        data = await body(req)
        clean, errors = {}, {}
        for key, raw in (data.get("values") or {}).items():
            val, err = fpvcfg.check_value(key, raw)
            if err:
                errors[key] = err
            else:
                clean[key] = val
        cur, _ = fpvcfg.load(config_path() if os.path.isfile(config_path()) else None)
        merged = {**cur, **clean}
        if not errors and merged["lq_return_pct"] <= merged["lq_switch_pct"]:
            errors["lq_return_pct"] = "must be higher than the switch value"
        if not errors and merged["video_height"] > 720 and merged["video_fps"] > 30:
            errors["video_fps"] = "above 720p the Pi 4 encoder manages 30 at most"
        if errors:
            return fail("Some values are not allowed", fields=errors)
        changed = {k: v for k, v in clean.items() if cur.get(k) != v}
        if changed:
            try:
                write_config(changed)
            except OSError as e:
                return fail(f"Could not write {config_path()}: {e}")
        return ok(changed=sorted(changed))

    async def post_apply(_req_):
        await body(_req_)
        code, out = await run([sys.executable, os.path.join(HERE, "apply_config.py")], timeout=40)
        if code != 0:
            return fail("apply_config.py failed", detail=out[-600:])
        await run(["systemctl", "restart", "fpv-mediamtx"])

        async def later():                         # answer first, then restart ourselves
            await asyncio.sleep(0.8)
            await run(["systemctl", "restart", "fpv-bridge"])
        asyncio.get_running_loop().create_task(later())
        return ok(boot=BOOT_ID, detail=out[-600:])

    async def post_rescan(req):
        """Look for newly plugged USB cameras and microphones, restart the video server."""
        await body(req)
        code, out = await run([sys.executable, os.path.join(HERE, "apply_config.py")], timeout=40)
        if code != 0:
            return fail("apply_config.py failed", detail=out[-600:])
        await run(["systemctl", "restart", "fpv-mediamtx"])
        return ok(paths=video_paths(), detail=out[-600:])

    def cam_values(emergency):
        cfg, _ = fpvcfg.load(config_path() if os.path.isfile(config_path()) else None)
        if emergency:
            # same picture size: only data rate and frame rate change, the video server takes these over
            # while running, so the picture does not stop (measured 25.11.2026: 5000 -> about 700 kbit/s within 2 s)
            return {"Width": cfg["video_width"], "Height": cfg["video_height"], "FPS": min(cfg["emergency_fps"], cfg["video_fps"]),
                    "Bitrate": cfg["emergency_bitrate_kbps"] * 1000, "IDRPeriod": cfg["emergency_fps"]}
        fps = cfg["video_fps"] if cfg["video_fps"] <= 30 or (cfg["video_width"] <= 1280 and cfg["video_height"] <= 720) else 30
        return {"Width": cfg["video_width"], "Height": cfg["video_height"], "FPS": fps,
                "Bitrate": cfg["video_bitrate_kbps"] * 1000, "IDRPeriod": max(cfg["video_idr_period"], fps) if fps > 30 else cfg["video_idr_period"]}

    def emergency_state():
        try:
            with open(os.path.join(apply_config.OUT_DIR, "mediamtx.yml"), encoding="utf-8") as f:
                m = re.search(r"rpiCameraBitrate:\s*(\d+)", f.read())
            return bool(m) and int(m.group(1)) == cam_values(True)["Bitrate"] != cam_values(False)["Bitrate"]
        except OSError:
            return False

    async def get_emergency(_req):
        return web.json_response({"on": emergency_state()})

    async def post_emergency(req):
        """Emergency picture on or off: only the numbers of the main camera in the video server's file change.
        The video server notices the changed file by itself and applies it without stopping the picture."""
        data = await body(req)
        on = bool(data.get("on"))
        path = os.path.join(apply_config.OUT_DIR, "mediamtx.yml")
        try:
            with open(path, encoding="utf-8") as f:
                txt = f.read()
            new = txt
            for key, val in cam_values(on).items():
                new = re.sub(rf"(rpiCamera{key}:\s*)\S+", rf"\g<1>{val}", new, count=1)
            if new != txt:
                tmp = path + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    f.write(new)
                os.replace(tmp, path)
        except OSError as e:
            return fail(f"Could not change the video server file: {e}")
        return ok(on=on, changed=new != txt)

    async def get_paths(_req):
        return web.json_response({"paths": video_paths()})

    async def get_system(_req):
        return web.json_response(await system_state())

    async def get_wifi(_req):
        return web.json_response(await wifi_state())

    async def wifi_add(req):
        data = await body(req)
        ssid, pw = clean_ssid(data.get("ssid")), str(data.get("password") or "")
        if not ssid:
            return fail("Network name: 1 to 32 characters")
        if pw and not 8 <= len(pw) <= 63:
            return fail("Password: 8 to 63 characters (or empty for an open network)")
        try:
            prio = max(0, min(99, int(data.get("priority", 10))))
        except (TypeError, ValueError):
            prio = 10
        await run(["nmcli", "connection", "delete", "id", ssid])      # replace an old entry
        cmd = ["nmcli", "connection", "add", "type", "wifi", "ifname", "wlan0", "con-name", ssid,
               "ssid", ssid, "connection.autoconnect", "yes",
               "connection.autoconnect-priority", str(prio)]
        if pw:
            cmd += ["wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", pw]
        code, out = await run(cmd)
        if code != 0:
            return fail("Could not save the network", detail=out[-300:])
        return ok()

    async def wifi_delete(req):
        data = await body(req)
        name = clean_ssid(data.get("name"))
        if not name:
            return fail("No network name")
        state = await wifi_state()
        if state["current"] and state["current"]["ssid"] == name and not data.get("sure"):
            return fail("The Pi is connected through this network right now", need_sure=True)
        code, out = await run(["nmcli", "connection", "delete", "id", name])
        return ok() if code == 0 else fail("Could not delete", detail=out[-300:])

    async def get_vpn(_req):
        return web.json_response(await vpn_state())

    async def vpn_upload(req):
        data = await body(req)
        text = str(data.get("text") or "")
        if len(text) > 8000 or "[Interface]" not in text or "[Peer]" not in text \
                or "PrivateKey" not in text:
            return fail("This is not a WireGuard file ([Interface], PrivateKey and [Peer] expected)")
        clean = apply_config.clean_wireguard(text)
        try:
            os.makedirs(apply_config.WG_DIR, exist_ok=True)
            dst = os.path.join(apply_config.WG_DIR, "wg0.conf")
            with open(dst, "w", encoding="utf-8") as f:
                f.write(clean)
            os.chmod(dst, 0o600)
        except OSError as e:
            return fail(f"Could not write the tunnel file: {e}")
        await run(["systemctl", "enable", "wg-quick@wg0"])
        code, out = await run(["systemctl", "restart", "wg-quick@wg0"])
        if code != 0:
            return fail("File saved, but the tunnel did not start", detail=out[-300:])
        return ok()

    async def vpn_enable(req):
        data = await body(req)
        if data.get("on"):
            await run(["systemctl", "enable", "wg-quick@wg0"])
            code, out = await run(["systemctl", "restart", "wg-quick@wg0"])
        else:
            await run(["systemctl", "disable", "wg-quick@wg0"])
            code, out = await run(["systemctl", "stop", "wg-quick@wg0"])
        return ok() if code == 0 else fail("Tunnel command failed", detail=out[-300:])

    async def vpn_remove(req):
        await body(req)
        await run(["systemctl", "disable", "--now", "wg-quick@wg0"])
        try:
            os.remove(os.path.join(apply_config.WG_DIR, "wg0.conf"))
        except FileNotFoundError:
            pass
        except OSError as e:
            return fail(f"Could not remove the tunnel file: {e}")
        return ok()

    async def get_log(req):
        unit = UNITS.get(req.query.get("unit", ""), None)
        if not unit:
            return fail("Unknown service")
        _, out = await run(["journalctl", "-u", unit, "-n", "60", "--no-pager", "-o", "short"])
        return ok(text=out)

    async def power(req):
        data = await body(req)
        action = data.get("action")
        if action not in ("reboot", "poweroff"):
            return fail("Unknown action")

        async def later():
            await asyncio.sleep(0.8)
            await run(["systemctl", action])
        asyncio.get_running_loop().create_task(later())
        return ok(boot=BOOT_ID)

    async def get_remote(_req):
        return web.json_response({**remote_state(), "tailscale": await tailscale_state()})

    async def remote_token(req):
        data = await body(req)
        tok = str(data.get("token") or "").strip()
        if not tok:                                   # empty = remove the token
            try:
                os.remove(REMOTE_TOKEN)
            except FileNotFoundError:
                pass
        elif not re.fullmatch(r"(github_pat_|ghp_)[A-Za-z0-9_]{20,250}", tok):
            return fail("This does not look like a GitHub token (github_pat_... or ghp_...)")
        else:
            try:
                os.makedirs(os.path.dirname(REMOTE_TOKEN), exist_ok=True)
                fd = os.open(REMOTE_TOKEN, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, "w") as f:
                    f.write(tok + "\n")
            except OSError as e:
                return fail(f"Could not store the token: {e}")
        await run(["systemctl", "restart", "fpv-remote"])
        return ok()

    async def remote_enable(req):
        data = await body(req)
        try:
            set_remote_enabled(bool(data.get("on")))
        except OSError as e:
            return fail(f"Could not write {REMOTE_CONF}: {e}")
        await run(["systemctl", "restart", "fpv-remote"])
        return ok()

    async def remote_log(req):
        name = req.query.get("name", "")
        if not re.fullmatch(r"\d{3,}_[\w.-]+", name):
            return fail("Unknown result")
        try:
            with open(os.path.join(REMOTE_STATE, "out", name + ".log"), encoding="utf-8",
                      errors="replace") as f:
                return ok(text=f.read()[-20000:])
        except OSError:
            return fail("Result not found")

    app.add_routes([
        web.get("/api/remote", get_remote), web.post("/api/remote/token", remote_token),
        web.post("/api/remote/enable", remote_enable), web.get("/api/remote/log", remote_log),
        web.post("/api/rescan", post_rescan), web.get("/api/paths", get_paths),
        web.get("/api/emergency", get_emergency), web.post("/api/emergency", post_emergency),
        web.get("/settings", page), web.get("/api/config", get_config),
        web.post("/api/config", post_config), web.post("/api/apply", post_apply),
        web.get("/api/system", get_system), web.get("/api/wifi", get_wifi),
        web.post("/api/wifi/add", wifi_add), web.post("/api/wifi/delete", wifi_delete),
        web.get("/api/vpn", get_vpn), web.post("/api/vpn/upload", vpn_upload),
        web.post("/api/vpn/enable", vpn_enable), web.post("/api/vpn/remove", vpn_remove),
        web.get("/api/log", get_log), web.post("/api/power", power),
    ])
